create PROCEDURE INSERT_INSPECTION_RESULT(
    /* 입력 매개변수 */
    p_equip_code IN NUMBER,                     -- 장비 코드
    p_platform_delivery_id IN NUMBER,           -- 플랫폼 배송 ID
    p_platform_delivery_return_id IN NUMBER,    -- 플랫폼 배송 반환 ID
    p_admin_id IN VARCHAR2,                     -- 관리자 ID
    p_inspec_items IN VARCHAR2,                 -- 검수 항목 ID 목록 (쉼표로 구분)
    p_inspec_grades IN VARCHAR2,                -- 검수 등급 값 목록 (쉼표로 구분)
    p_inspec_scores IN VARCHAR2,                -- 검수 점수 목록 (쉼표로 구분)
    p_inspec_comments IN VARCHAR2,              -- 검수 코멘트 목록 (쉼표로 구분)
    p_total_score IN NUMBER,                    -- 총 점수
    p_final_grade IN VARCHAR2,                  -- 최종 등급

    /* 출력 매개변수 */
    p_inspec_result_id OUT NUMBER               -- 생성된 검수 결과 ID
) AS
    /* 지역 변수 선언 */
    v_inspec_result_id NUMBER;                  -- 검수 결과 ID 저장 변수
    v_equip_grade_id NUMBER;                    -- 장비 등급 ID 저장 변수

    /* 문자열 파싱을 위한 변수 */
    v_items_list VARCHAR2(4000) := p_inspec_items;      -- 검수 항목 ID 리스트 작업용 복사본
    v_grades_list VARCHAR2(4000) := p_inspec_grades;    -- 등급 리스트 작업용 복사본
    v_scores_list VARCHAR2(4000) := p_inspec_scores;    -- 점수 리스트 작업용 복사본
    v_comments_list VARCHAR2(4000) := p_inspec_comments;-- 코멘트 리스트 작업용 복사본

    /* 각 항목의 단일 값 저장 변수 */
    v_item_id_str VARCHAR2(100);                -- 항목 ID 문자열
    v_grade_str VARCHAR2(100);                  -- 등급 문자열
    v_score_str VARCHAR2(100);                  -- 점수 문자열
    v_comment_str VARCHAR2(600);                -- 코멘트 문자열

    /* 문자열 파싱 위치 변수 */
    v_pos1 NUMBER;                              -- 항목 ID 구분자 위치
    v_pos2 NUMBER;                              -- 등급 구분자 위치
    v_pos3 NUMBER;                              -- 점수 구분자 위치
    v_pos4 NUMBER;                              -- 코멘트 구분자 위치

    /* 변환된 값 저장 변수 */
    v_item_id NUMBER;                           -- 항목 ID 숫자값
    v_grade VARCHAR2(10);                       -- 등급 값 (상, 중, 하)
    v_score NUMBER;                             -- 점수 숫자값
    v_comment VARCHAR2(600);                    -- 코멘트 값
    v_inspec_grade_id NUMBER;                   -- 검수 등급 ID
BEGIN
    /* 1. 최종 등급에 해당하는 EQUIP_GRADE_ID 조회 */
    BEGIN
        -- 입력된 최종 등급(A, B, C 등)에 대응하는 ID 값 조회
        SELECT EQUIP_GRADE_ID INTO v_equip_grade_id
        FROM EQUIP_GRADE
        WHERE EQUIP_GRADE_NAME = p_final_grade;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            -- 조회 결과가 없으면 기본 등급(1)으로 설정
            v_equip_grade_id := 1;
    END;

    /* 2. 검수 결과 테이블에 마스터 레코드 삽입 */
    INSERT INTO INSPEC_RESULT (
        INSPEC_RESULT_ID,           -- 검수 결과 ID
        PLATFORM_DELIVERY_ID,       -- 플랫폼 배송 ID
        PLATFORM_DELIVERY_RETURN_ID,-- 플랫폼 배송 반환 ID
        EQUIP_GRADE_ID              -- 장비 등급 ID
    ) VALUES (
                 INSPEC_RESULT_SEQ.NEXTVAL,  -- 시퀀스를 사용하여 자동 생성된 ID
                 p_platform_delivery_id,     -- 입력된 플랫폼 배송 ID
                 p_platform_delivery_return_id, -- 입력된 플랫폼 배송 반환 ID
                 v_equip_grade_id            -- 조회된 장비 등급 ID
             ) RETURNING INSPEC_RESULT_ID INTO v_inspec_result_id; -- 생성된 ID 반환

    /* 3. 검수 항목별 상세 정보 파싱 및 삽입 처리 */
    WHILE LENGTH(v_items_list) > 0 LOOP
            /* 3-1. 항목 ID 추출 */
            v_pos1 := INSTR(v_items_list, ',');  -- 첫 번째 쉼표 위치 찾기
            IF v_pos1 = 0 THEN
                -- 쉼표가 없으면 남은 전체 문자열을 항목 ID로 설정
                v_item_id_str := v_items_list;
                v_items_list := '';  -- 리스트 비우기
            ELSE
                -- 쉼표가 있으면 쉼표 앞부분을 항목 ID로 설정하고 리스트 업데이트
                v_item_id_str := SUBSTR(v_items_list, 1, v_pos1 - 1);
                v_items_list := SUBSTR(v_items_list, v_pos1 + 1);  -- 쉼표 이후 문자열로 갱신
            END IF;

            /* 3-2. 등급 추출 */
            v_pos2 := INSTR(v_grades_list, ',');  -- 첫 번째 쉼표 위치 찾기
            IF v_pos2 = 0 THEN
                -- 쉼표가 없으면 남은 전체 문자열을 등급으로 설정
                v_grade_str := v_grades_list;
                v_grades_list := '';  -- 리스트 비우기
            ELSE
                -- 쉼표가 있으면 쉼표 앞부분을 등급으로 설정하고 리스트 업데이트
                v_grade_str := SUBSTR(v_grades_list, 1, v_pos2 - 1);
                v_grades_list := SUBSTR(v_grades_list, v_pos2 + 1);  -- 쉼표 이후 문자열로 갱신
            END IF;

            /* 3-3. 점수 추출 */
            v_pos3 := INSTR(v_scores_list, ',');  -- 첫 번째 쉼표 위치 찾기
            IF v_pos3 = 0 THEN
                -- 쉼표가 없으면 남은 전체 문자열을 점수로 설정
                v_score_str := v_scores_list;
                v_scores_list := '';  -- 리스트 비우기
            ELSE
                -- 쉼표가 있으면 쉼표 앞부분을 점수로 설정하고 리스트 업데이트
                v_score_str := SUBSTR(v_scores_list, 1, v_pos3 - 1);
                v_scores_list := SUBSTR(v_scores_list, v_pos3 + 1);  -- 쉼표 이후 문자열로 갱신
            END IF;

            /* 3-4. 코멘트 추출 (|| 구분자 사용) */
            v_pos4 := INSTR(v_comments_list, '||');  -- 첫 번째 '||' 위치 찾기
            IF v_pos4 = 0 THEN
                -- '||'가 없으면 남은 전체 문자열을 코멘트로 설정
                v_comment_str := v_comments_list;
                v_comments_list := '';  -- 리스트 비우기
            ELSE
                -- '||'가 있으면 앞부분을 코멘트로 설정하고 리스트 업데이트
                v_comment_str := SUBSTR(v_comments_list, 1, v_pos4 - 1);
                v_comments_list := SUBSTR(v_comments_list, v_pos4 + 2);  -- '||' 이후 문자열로 갱신
            END IF;

            /* 3-5. 문자열을 적절한 데이터 타입으로 변환 */
            v_item_id := TO_NUMBER(TRIM(v_item_id_str));  -- 공백 제거 후 숫자로 변환
            v_grade := TRIM(v_grade_str);                  -- 공백 제거
            v_score := TO_NUMBER(TRIM(v_score_str));      -- 공백 제거 후 숫자로 변환
            v_comment := TRIM(v_comment_str);              -- 공백 제거

            /* 3-6. 등급 이름('상', '중', '하')에 해당하는 INSPEC_GRADE_ID 조회 */
            BEGIN
                SELECT INSPEC_GRADE_ID INTO v_inspec_grade_id
                FROM INSPEC_GRADE
                WHERE INSPEC_GRADE_NAME = v_grade;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    -- 등급이 없는 경우 기본값(1) 설정
                    v_inspec_grade_id := 1;
            END;

            /* 3-7. 해당 항목에 대한 CATE_INSPEC_ID 찾고 검수 리스트에 삽입 */
            DECLARE
                v_cate_inspec_id NUMBER;  -- 카테고리 검수 ID
            BEGIN
                -- 항목 ID로 CATE_INSPEC 테이블에서 관련 ID 조회
                SELECT CATE_INSPEC_ID INTO v_cate_inspec_id
                FROM CATE_INSPEC
                WHERE INSPEC_ITEM_ID = v_item_id
                  AND ROWNUM = 1;  -- 첫 번째 결과만 사용

                -- 검수 항목 리스트 테이블에 레코드 삽입
                INSERT INTO INSPEC_LIST (
                    INSPEC_LIST_ID,            -- 검수 리스트 ID
                    INSPEC_COMMENT,            -- 검수 코멘트
                    CATE_INSPEC_ID,            -- 카테고리 검수 ID
                    PLATFORM_DELIVERY_ID,      -- 플랫폼 배송 ID
                    PLATFORM_DELIVERY_RETURN_ID, -- 플랫폼 배송 반환 ID
                    ADMIN_ID,                  -- 관리자 ID
                    INSPEC_GRADE_ID,           -- 검수 등급 ID
                    INSPECTION_DATE            -- 검수 일자
                ) VALUES (
                             INSPEC_LIST_SEQ.NEXTVAL,   -- 시퀀스로 자동 생성된 ID
                             v_comment,                 -- 추출된 코멘트
                             v_cate_inspec_id,          -- 조회된 카테고리 검수 ID
                             p_platform_delivery_id,    -- 입력된 플랫폼 배송 ID
                             p_platform_delivery_return_id, -- 입력된 플랫폼 배송 반환 ID
                             p_admin_id,                -- 입력된 관리자 ID
                             v_inspec_grade_id,         -- 조회된 검수 등급 ID
                             SYSDATE                    -- 현재 시스템 일자
                         );
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    -- 해당 항목이 없는 경우 무시하고 계속 진행
                    NULL;
            END;
        END LOOP;

    /* 4. 검수 결과 처리 - 결과 처리 액션 기록 */
    DECLARE
        v_inspec_result_action_type_id NUMBER;  -- 검수 결과 처리 유형 ID
    BEGIN
        -- '완료' 액션 타입 ID 조회
        SELECT INSPEC_RESULT_ACTION_TYPE_ID INTO v_inspec_result_action_type_id
        FROM INSPEC_RESULT_ACTION_TYPE
        WHERE INSPEC_RESULT_ACTION_TYPE_NAME = '완료'
          AND ROWNUM = 1;  -- 첫 번째 결과만 사용

        -- 검수 결과 처리 테이블에 레코드 삽입
        INSERT INTO INSPEC_RESULT_ACTION (
            INSPEC_RESULT_ACTION_ID,     -- 검수 결과 처리 ID
            INSPEC_RESULT_ID,            -- 검수 결과 ID
            INSPEC_RESULT_ACTION_TYPE_ID, -- 검수 결과 처리 유형 ID
            COMPLETED_DATE               -- 완료 일자
        ) VALUES (
                     INSPEC_RESULT_ACTION_SEQ.NEXTVAL, -- 시퀀스로 자동 생성된 ID
                     v_inspec_result_id,          -- 생성된 검수 결과 ID
                     v_inspec_result_action_type_id, -- 조회된 처리 유형 ID
                     SYSDATE                      -- 현재 시스템 일자
                 );
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            -- 처리 유형이 없는 경우 무시하고 계속 진행
            NULL;
    END;

    /* 5. 생성된 검수 결과 ID 반환 */
    p_inspec_result_id := v_inspec_result_id;

    /* 6. 모든 작업 커밋 */
    COMMIT;
EXCEPTION
    /* 예외 처리 */
    WHEN OTHERS THEN
        -- 오류 발생 시 모든 변경 롤백
        ROLLBACK;
        -- 예외 다시 발생시켜 호출자에게 전달
        RAISE;
END;
/

