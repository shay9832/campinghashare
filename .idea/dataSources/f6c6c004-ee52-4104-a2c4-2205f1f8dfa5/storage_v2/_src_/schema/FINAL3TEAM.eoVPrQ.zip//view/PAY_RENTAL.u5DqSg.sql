create view PAY_RENTAL as
SELECT UR.회원_코드, UR.장비등록_장비코드, UR.렌탈_ID, P.PAY_AMOUNT AS 결제_금액, P.PAY_DATE AS 결제_일자, PAY_ID AS 결제_ID
FROM USER_RENTAL UR JOIN PAY P
                         ON UR.렌탈_ID = P.PAY_ID
/

