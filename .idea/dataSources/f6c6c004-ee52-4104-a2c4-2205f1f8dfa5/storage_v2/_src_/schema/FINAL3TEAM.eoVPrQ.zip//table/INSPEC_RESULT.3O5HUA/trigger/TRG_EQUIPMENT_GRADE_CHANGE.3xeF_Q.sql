create trigger TRG_EQUIPMENT_GRADE_CHANGE
    after insert
    on INSPEC_RESULT
    for each row
DECLARE
    v_equip_code NUMBER;
    v_prev_info VARCHAR2(10);
    v_prev_grade_id NUMBER;
    v_prev_grade CHAR(1);
    v_new_grade_id NUMBER := :NEW.EQUIP_GRADE_ID;
    v_new_grade CHAR(1);
    v_platform_delivery_return_id NUMBER := :NEW.PLATFORM_DELIVERY_RETURN_ID;
    v_result_action_id NUMBER;
BEGIN
    -- 검수결과에 따른 등급 정보 가져오기
    SELECT EQUIP_GRADE_NAME INTO v_new_grade
    FROM EQUIP_GRADE
    WHERE EQUIP_GRADE_ID = v_new_grade_id;

    -- 반환 검수인 경우에만 처리 (PLATFORM_DELIVERY_RETURN_ID가 NOT NULL인 경우)
    IF v_platform_delivery_return_id IS NOT NULL THEN
        -- 장비 코드 가져오기
        SELECT EC.EQUIP_CODE INTO v_equip_code
        FROM PLATFORM_DELIVERY_RETURN PDR
        JOIN PLATFORM_DELIVERY PD ON PDR.PLATFORM_DELIVERY_ID = PD.PLATFORM_DELIVERY_ID
        JOIN PAY P ON PD.PAY_ID = P.PAY_ID
        JOIN STOREN_MATCHING_DONE SMD ON P.STOREN_MATCHING_DONE_ID = SMD.STOREN_MATCHING_DONE_ID
        JOIN STOREN_MATCHING_REQ SMR ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
        JOIN STOREN_IRA SI ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
        JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
        JOIN EQUIP_CODE EC ON S.EQUIP_CODE = EC.EQUIP_CODE
        WHERE PDR.PLATFORM_DELIVERY_RETURN_ID = v_platform_delivery_return_id;

        -- 독립 함수를 통해 이전 등급 정보 가져오기
        v_prev_info := GET_PREV_GRADE_INFO(v_equip_code);

        -- 반환된 정보 파싱 ('등급ID,등급명' 형태)
        v_prev_grade_id := TO_NUMBER(SUBSTR(v_prev_info, 1, INSTR(v_prev_info, ',') - 1));
        v_prev_grade := SUBSTR(v_prev_info, INSTR(v_prev_info, ',') + 1);

        -- 등급이 하락했는지 확인 (알파벳순으로 A가 가장 좋은 등급, F가 가장 나쁜 등급)
        IF v_prev_grade IS NOT NULL AND v_new_grade > v_prev_grade THEN
            -- 검수 결과 처리 액션 ID 저장 (INSPEC_RESULT_ACTION 테이블 INSERT 후 ID 가져오기)
            INSERT INTO INSPEC_RESULT_ACTION (
                INSPEC_RESULT_ACTION_ID,
                INSPEC_RESULT_ID,
                INSPEC_RESULT_ACTION_TYPE_ID,
                COMPLETED_DATE
            ) VALUES (
                INSPEC_RESULT_ACTION_SEQ.NEXTVAL,
                :NEW.INSPEC_RESULT_ID,
                1, -- '스토렌 입고' 액션 타입
                SYSDATE
            ) RETURNING INSPEC_RESULT_ACTION_ID INTO v_result_action_id;

            -- 렌터 문제(파손) 기록
            INSERT INTO RENTER_PROBLEM (
                RENTER_PROBLEM_ID,
                RENTER_PROBLEM_TYPE_ID,
                INSPEC_RESULT_ACTION_ID,
                PROBLEM_REPORTED_DATE
            ) VALUES (
                RENTER_PROBLEM_SEQ.NEXTVAL,
                2, -- 파손(2번) 문제 유형
                v_result_action_id,
                SYSDATE
            );

            -- 해당 장비의 모든 활성 스토렌 및 예약 취소 프로시저 호출
            EXECUTE IMMEDIATE 'BEGIN PRC_CANCEL_EQUIPMENT_RENTALS(:1, :2, :3); END;' 
            USING v_equip_code, '장비 손상으로 인한 등급 하락 (이전: ' || v_prev_grade || ', 현재: ' || v_new_grade || ')', v_result_action_id;
        END IF;
    END IF;
END;
/

