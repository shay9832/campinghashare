create view USER_STORAGE as
SELECT TP.회원_코드, TP.장비등록_장비코드, SR.STORAGE_ID AS 보관_ID
FROM T_PRICE TP JOIN STORAGE SR
                     ON TP.장비등록_장비코드 = SR.EQUIP_CODE
/

