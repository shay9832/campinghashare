create trigger TRG_CREATE_NEW_STOREN_TICKET
    after insert
    on STOREN_MATCHING_DONE
    for each row
DECLARE
    v_storen_id NUMBER;
    v_new_storen_id NUMBER;
    v_equip_code NUMBER;
    v_size_id NUMBER;
    v_remaining_months NUMBER;
    v_storen_title VARCHAR2(90);
    v_storen_content VARCHAR2(1000);
    v_daily_rent_price NUMBER(8);
    v_req_id NUMBER;
    v_start_date DATE;
    v_end_date DATE;
    v_days_rented NUMBER;
    v_ira_id NUMBER;
    v_inspec_result_action_id NUMBER;
    v_problem_exists NUMBER := 0;
    v_equip_inactive NUMBER := 0;
BEGIN
    -- 1. 매칭 신청 정보 가져오기
    v_req_id := :NEW.STOREN_MATCHING_REQ_ID;

    -- 2. 매칭 신청 정보에서 STOREN_IRA_ID와 날짜 정보 가져오기
    SELECT STOREN_IRA_ID, RENTAL_START_DATE, RENTAL_END_DATE
    INTO v_ira_id, v_start_date, v_end_date
    FROM STOREN_MATCHING_REQ
    WHERE STOREN_MATCHING_REQ_ID = v_req_id;

    -- 3. STOREN_IRA에서 STOREN_ID와 INSPEC_RESULT_ACTION_ID 가져오기
    SELECT STOREN_ID, INSPEC_RESULT_ACTION_ID
    INTO v_storen_id, v_inspec_result_action_id
    FROM STOREN_IRA
    WHERE STOREN_IRA_ID = v_ira_id;

    -- 4. 원본 STOREN 정보 가져오기
    SELECT EQUIP_CODE, SIZE_ID, STORE_MONTH, 
           STOREN_TITLE, STOREN_CONTENT, DAILY_RENT_PRICE
    INTO v_equip_code, v_size_id, v_remaining_months, 
         v_storen_title, v_storen_content, v_daily_rent_price
    FROM STOREN
    WHERE STOREN_ID = v_storen_id;

    -- 5. 장비 코드가 이미 비활성화된 상태인지 확인
    IF v_equip_code IS NULL THEN
        DBMS_OUTPUT.PUT_LINE('장비 코드가 NULL이어서 새 스토렌 티켓이 생성되지 않았습니다.');
        RETURN;
    END IF;

    -- EQUIP_CODE 테이블에서 소유 종료 여부 확인
    SELECT COUNT(*)
    INTO v_equip_inactive
    FROM EQUIP_CODE
    WHERE EQUIP_CODE = v_equip_code
    AND OWN_END_DATE IS NOT NULL;

    IF v_equip_inactive > 0 THEN
        DBMS_OUTPUT.PUT_LINE('장비가 비활성화되어 새 스토렌 티켓이 생성되지 않았습니다. EQUIP_CODE: ' || v_equip_code);
        RETURN;
    END IF;

    -- 6. 장비에 대한 미해결 문제가 있는지 확인 (뷰 사용)
    SELECT COUNT(*) INTO v_problem_exists
    FROM (
        -- 취소된 결제가 있는지 확인 (장비에 문제가 있었던 이력 확인)
        SELECT 1
        FROM PAY_CANCEL PC
        JOIN PAY P ON PC.PAY_ID = P.PAY_ID
        WHERE P.PAY_ID IN (
            SELECT PAY_ID
            FROM VW_PAY_ID_TO_EQUIP_CODE
            WHERE 장비코드 = v_equip_code
        )
        AND PC.PAY_CANCEL_REASON_ID IN (5, 6, 7) -- 연체, 파손, 분실 관련 사유
        -- 이 취소가 최근 24시간 이내에 발생했는지 확인 (오래된 취소는 무시)
        AND PC.CANCEL_DATE > SYSDATE - 1
    );

    -- 장비에 미해결 문제가 있으면 새 티켓 생성 중단
    IF v_problem_exists > 0 THEN
        DBMS_OUTPUT.PUT_LINE('장비에 미해결 문제가 있어 새 스토렌 티켓이 생성되지 않았습니다. EQUIP_CODE: ' || v_equip_code);
        RETURN;
    END IF;

    -- 7. 렌탈된 일수 계산
    v_days_rented := v_end_date - v_start_date + 1;

    -- 8. 남은 보관개월수 계산 (렌탈된 일수를 30일로 나누어 월 단위로 계산 후 차감)
    v_remaining_months := v_remaining_months - CEIL(v_days_rented / 30);

    -- 남은 보관개월수가 0 이하면 더 이상 새 티켓을 생성하지 않음
    IF v_remaining_months <= 0 THEN
        RETURN;
    END IF;

    -- 9. 새로운 STOREN ID 생성 (시퀀스 사용)
    SELECT STOREN_SEQ.NEXTVAL
    INTO v_new_storen_id
    FROM DUAL;

    -- 10. 새 STOREN 티켓 생성
    INSERT INTO STOREN (
        STOREN_ID, 
        EQUIP_CODE, 
        SIZE_ID, 
        STORE_MONTH, 
        STOREN_TITLE, 
        STOREN_CONTENT, 
        DAILY_RENT_PRICE, 
        CREATED_DATE
    ) VALUES (
        v_new_storen_id,
        v_equip_code,
        v_size_id,
        v_remaining_months,
        v_storen_title,
        v_storen_content,
        v_daily_rent_price,
        SYS
    /

