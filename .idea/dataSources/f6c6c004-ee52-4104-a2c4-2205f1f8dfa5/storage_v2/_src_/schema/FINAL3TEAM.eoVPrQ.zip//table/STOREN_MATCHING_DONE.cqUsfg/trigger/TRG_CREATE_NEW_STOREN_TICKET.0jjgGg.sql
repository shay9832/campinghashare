create trigger TRG_CREATE_NEW_STOREN_TICKET
    after insert
    on STOREN_MATCHING_DONE
    for each row
DECLARE
    v_storen_id                 STOREN.STOREN_ID%TYPE;                          --이전(방금 매칭승인된) 스토렌_ID   [3]
    v_new_storen_id             STOREN.STOREN_ID%TYPE;                          --새로 생성할 스토렌_ID
    v_equip_code                STOREN.EQUIP_CODE%TYPE;                         --기존 스토렌 정보(장비코드)        [5]
    v_size_id                   STOREN.SIZE_ID%TYPE;                            --기존 스토렌 정보(사이즈)          [5]
    v_remaining_months          STOREN.STORE_MONTH%TYPE;                        --기존 스토렌 정보(보관개월수)      [5]
    v_storen_title              STOREN.STOREN_TITLE%TYPE;                       --기존 스토렌 정보(스토렌 타이틀)   [5]
    v_storen_content            STOREN.STOREN_CONTENT%TYPE;                     --기존 스토렌 정보(스토렌 내용)     [5]
    v_daily_rent_price          STOREN.DAILY_RENT_PRICE%TYPE;                   --기존 스토렌 정보(일일렌탈비)      [5]
    v_req_id                    STOREN_MATCHING_REQ.STOREN_MATCHING_REQ_ID%TYPE;--매칭신청_ID                      [1]
    v_start_date                STOREN_MATCHING_REQ.RENTAL_START_DATE%TYPE;     --(사용자)렌탈시작일                [2]
    v_end_date                  STOREN_MATCHING_REQ.RENTAL_END_DATE%TYPE;       --(사용자)렌탈종료일                [2]
    v_ira_id                    STOREN_MATCHING_REQ.STOREN_IRA_ID%TYPE;           --이전 묶음 IRA_ID               [2]
    v_inspec_result_action_id   INSPEC_RESULT_ACTION.INSPEC_RESULT_ACTION_ID%TYPE;--기존 스토렌ID의 검수결과처리_ID  [3]'
    v_inspec_result_action_date INSPEC_RESULT_ACTION.COMPLETED_DATE%TYPE;       --기존 스토렌ID의 검수결과일=입고일  [4]
    v_problem_exists NUMBER := 0;   --장비에 미해결 문제 있는지 확인                   [7]
    v_equip_inactive NUMBER := 0;   --장비에 문제가 생겨서 소유종료가 되었는지 확인     [6]
BEGIN
    -- [1] 매칭 신청 정보 가져오기
    v_req_id := :NEW.STOREN_MATCHING_REQ_ID;

    -- [2] 매칭 신청 정보에서 STOREN_IRA_ID와 날짜 정보 가져오기
    SELECT STOREN_IRA_ID, RENTAL_START_DATE, RENTAL_END_DATE
    INTO v_ira_id, v_start_date, v_end_date
    FROM STOREN_MATCHING_REQ
    WHERE STOREN_MATCHING_REQ_ID = v_req_id;

    -- [3] STOREN_IRA에서 STOREN_ID와 INSPEC_RESULT_ACTION_ID 가져오기
    SELECT STOREN_ID, INSPEC_RESULT_ACTION_ID
    INTO v_storen_id, v_inspec_result_action_id
    FROM STOREN_IRA
    WHERE STOREN_IRA_ID = v_ira_id;

    -- [4] INSPEC_RESULT_ACTIONd에서 COMPLETED_DATE 가져오기
    SELECT COMPLETED_DATE
    INTO v_inspec_result_action_date
    FROM INSPEC_RESULT_ACTION
    WHERE INSPEC_RESULT_ACTION_ID = v_inspec_result_action_id;

    -- [5] 원본 STOREN 정보 가져오기
    SELECT EQUIP_CODE, SIZE_ID, STORE_MONTH, 
           STOREN_TITLE, STOREN_CONTENT, DAILY_RENT_PRICE
    INTO v_equip_code, v_size_id, v_remaining_months, 
         v_storen_title, v_storen_content, v_daily_rent_price
    FROM STOREN
    WHERE STOREN_ID = v_storen_id;

    -- [6] EQUIP_CODE 테이블에서 소유 종료 여부 확인
    SELECT COUNT(*)
    INTO v_equip_inactive
    FROM EQUIP_CODE
    WHERE EQUIP_CODE = v_equip_code
    AND OWN_END_DATE IS NOT NULL;

    IF v_equip_inactive > 0 THEN
        DBMS_OUTPUT.PUT_LINE('장비가 비활성화되어 새 스토렌 티켓이 생성되지 않았습니다. EQUIP_CODE: ' || v_equip_code);
        RETURN;
    END IF;

    -- [7] 장비에 대한 미해결 문제가 있는지 확인 (뷰 사용)
    SELECT COUNT(*) INTO v_problem_exists
    FROM (
        -- 취소된 결제가 있는지 확인 (장비에 문제가 있었던 이력 확인)
        SELECT 1
        FROM PAY_CANCEL PC
        JOIN PAY P ON PC.PAY_ID = P.PAY_ID
        WHERE P.PAY_ID IN (
            SELECT PAY_ID
            FROM VW_PAY_ID_TO_EQUIP_CODE
            WHERE 장비
    /

