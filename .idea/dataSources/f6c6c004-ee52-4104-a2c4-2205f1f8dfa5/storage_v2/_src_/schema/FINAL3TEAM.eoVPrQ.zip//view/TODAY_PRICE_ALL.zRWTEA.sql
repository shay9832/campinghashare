create view TODAY_PRICE_ALL as
SELECT SP.회원_코드,SP.스토렌_ID,SP.스토렌_매칭_완료_ID,SP.결제_금액 AS 스토렌_결제_금액,PST.결제_금액 AS 보관_결제_금액,PST.결제_일자 AS 보관_결제_일자,PR.결제_금액 AS 렌탈_결제_금액,PR.결제_일자 AS 렌탈_결제_일자
FROM STOREN_PAY SP JOIN PAY_STOREN PS
ON SP.회원_코드 = PS.회원_코드
JOIN PAY_STORAGE PST
ON PS.회원_코드 = PST.회원_코드
JOIN PAY_RENTAL PR
ON PST.회원_코드 = PR.회원_코드
JOIN RENTAL_MATCHING RM
ON PR.회원_코드 = RM.회원_코드
/

