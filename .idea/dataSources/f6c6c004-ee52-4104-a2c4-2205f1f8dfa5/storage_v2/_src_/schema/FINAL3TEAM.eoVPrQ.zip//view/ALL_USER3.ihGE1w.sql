create view ALL_USER3 as
SELECT 회원아이디,회원코드,회원이름,회원전화번호,회원닉네임,회원이메일,장비아이디,장비코드,카테고리아이디,장비이름아이디
       ,신품가격,생성일,ST.STORE_MONTH AS 보관개월수, ST.STOREN_TITLE AS 스토렌제목, ST.RENT_CONTENT 상품내용
       , ST.DAILY_RENT_PRICE AS 렌탈가격,ST.CREATED_DATE AS 스토렌생성일
FROM ALL_USER2 AU JOIN STOREN ST
ON AU.장비코드 = ST.EQUIP_CODE
/

