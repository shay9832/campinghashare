create trigger TRG_EQUIPMENT_LOST
    after insert
    on RENTER_PROBLEM_LOST
    for each row
DECLARE
    v_equip_code NUMBER;
    v_original_price NUMBER;
    v_storen_matching_done_id NUMBER := :NEW.STOREN_MATCHING_DONE_ID;
BEGIN
    -- 1. 분실된 장비 코드와 신품가격 정보 가져오기
    SELECT S.EQUIP_CODE, ER.ORIGINAL_PRICE
    INTO v_equip_code, v_original_price
    FROM STOREN_MATCHING_DONE SMD
    JOIN STOREN_MATCHING_REQ SMR ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
    JOIN STOREN_IRA SI ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
    JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
    JOIN EQUIPMENT_REGISTRATION ER ON S.EQUIP_CODE = ER.EQUIP_CODE
    WHERE SMD.STOREN_MATCHING_DONE_ID = v_storen_matching_done_id;

    -- 2. 분실에 대한 추가 결제 요청 생성 (신품가격의 90%)
    INSERT INTO RENTER_ADD_PAY (
        RENTER_ADD_PAY_ID,
        RENTER_PROBLEM_LOST_ID,
        RENTER_ADD_PAY_AMOUNT,
        PAY_DATE
    ) VALUES (
        RENTER_ADD_PAY_SEQ.NEXTVAL,
        :NEW.RENTER_PROBLEM_LOST_ID,
        ROUND(v_original_price * 0.9),
        NULL -- 결제 전
    );

    -- 3. 장비의 모든 활성 스토렌 및 예약 취소 프로시저 호출
    EXECUTE IMMEDIATE 'BEGIN PRC_CANCEL_EQUIPMENT_RENTALS(:1, :2, NULL); END;' 
    USING v_equip_code, '장비 분실 신고로 인한 취소';

    -- 4. 장비 소유 종료 처리 (EQUIP_CODE 테이블에 기록)
    UPDATE EQUIP_CODE
    SET OWN_END_DATE = SYSDATE
    WHERE EQUIP_CODE = v_equip_code
    AND OWN_END_DATE IS NULL;

    -- 5. 로그 기록
    DBMS_OUTPUT.PUT_LINE('장비 분실 처리 완료. EQUIP_CODE: ' || v_equip_code || ', 보상금액: ' || ROUND(v_original_price * 0.9));

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('분실 처리 중 오류 발생: ' || SQLERRM);
        -- 실제 환경에서는 적절한 로그 테이블에 오류 기록
END;
/

