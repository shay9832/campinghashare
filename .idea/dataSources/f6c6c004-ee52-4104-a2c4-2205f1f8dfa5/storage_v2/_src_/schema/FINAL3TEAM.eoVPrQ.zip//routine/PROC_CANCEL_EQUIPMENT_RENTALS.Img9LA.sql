create PROCEDURE PROC_CANCEL_EQUIPMENT_RENTALS(
    p_equip_code IN NUMBER,
    p_reason IN VARCHAR2,
    p_result_action_id IN NUMBER DEFAULT NULL
) 
AS
    v_log_message VARCHAR2(1000);
    v_updated_count NUMBER := 0;
    v_new_id NUMBER;
BEGIN
    v_log_message := '장비 코드 ' || p_equip_code || '에 대한 취소 사유: ' || p_reason;

    -- 로깅
    DBMS_OUTPUT.PUT_LINE(v_log_message);

    -- 1. 이전에 생성된 매칭 요청 중 아직 승인되지 않은 것들은 취소 처리
    -- 현재는 아직 매칭되지 않은 요청만 삭제 (거래 내역이 아직 없으므로)
    DELETE FROM STOREN_MATCHING_REQ SMR
    WHERE EXISTS (
        SELECT 1
        FROM STOREN_IRA SI
        JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
        WHERE SI.STOREN_IRA_ID = SMR.STOREN_IRA_ID
        AND S.EQUIP_CODE = p_equip_code
    )
    AND NOT EXISTS (
        SELECT 1
        FROM STOREN_MATCHING_DONE SMD
        WHERE SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
    );

    -- 2. 매칭 완료 되었지만 아직 결제가 안 된 건들에 대한 처리
    FOR r IN (
        SELECT P.PAY_ID
        FROM PAY P
        JOIN STOREN_MATCHING_DONE SMD ON P.STOREN_MATCHING_DONE_ID = SMD.STOREN_MATCHING_DONE_ID
        JOIN STOREN_MATCHING_REQ SMR ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
        JOIN STOREN_IRA SI ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
        JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
        WHERE S.EQUIP_CODE = p_equip_code
        AND P.PAY_DATE IS NULL  -- 결제 미완료 건
        AND NOT EXISTS (
            SELECT 1
            FROM PAY_CANCEL PC
            WHERE PC.PAY_ID = P.PAY_ID
        )
    ) LOOP
        -- 결제 미완료 건에 대한 취소 처리
        INSERT INTO PAY_CANCEL (
            PAY_CANCEL_ID,
            PAY_ID,
            CANCEL_DATE,
            PAY_CANCEL_REASON_ID
        ) VALUES (
            PAY_CANCEL_SEQ.NEXTVAL,
            r.PAY_ID,
            SYSDATE,
            CASE
                WHEN INSTR(p_reason, '지연') > 0 THEN 5 -- 이전 사용자 연체
                WHEN INSTR(p_reason, '손상') > 0 THEN 6 -- 이전 사용자 파손
                WHEN INSTR(p_reason, '분실') > 0 THEN 7 -- 이전 사용자 분실
                ELSE 7 -- 기타 이유
            END
        );
    END LOOP;

    -- 3. 결제가 완료된 건들에 대해서는 결제 취소 처리
    INSERT INTO PAY_CANCEL (
        PAY_CANCEL_ID,
        PAY_ID,
        CANCEL_DATE,
        PAY_CANCEL_REASON_ID
    )
    SELECT 
        PAY_CANCEL_SEQ.NEXTVAL,
        P.PAY_ID,
        SYSDATE,
        CASE
            WHEN INSTR(p_reason, '지연') > 0 THEN 5 -- 이전 사용자 연체
            WHEN INSTR(p_reason, '손상') > 0 THEN 6 -- 이전 사용자 파손
            WHEN INSTR(p_reason, '분실') > 0 THEN 7 -- 이전 사용자 분실
            ELSE 7 -- 기타 이유
        END
    FROM PAY P
    JOIN STOREN_MATCHING_DONE SMD ON P.STOREN_MATCHING_DONE_ID = SMD.STOREN_MATCHING_DONE_ID
    JOIN STOREN_MATCHING_REQ SMR ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
    JOIN STOREN_IRA SI ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
    JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
    WHERE S.EQUIP_CODE = p_equip_code
    AND P.PAY_DATE IS NOT NULL  -- 결제 완료 건
    AND NOT EXISTS (
        SELECT 1
        FROM PAY_CANCEL PC
        WHERE PC.PAY_ID = P.PAY_ID
    )
    AND P.STOREN_MATCHING_DONE_ID IS NOT NULL;

    -- 4. 문제 유형에 따른 처리
    IF INSTR(p_reason, '분실') > 0 OR INSTR(p_reason, '손상') > 0 THEN
        -- 장비 코드 소유 종료 처리만 수행
        UPDATE EQUIP_CODE
        SET OWN_END_DATE = SYSDATE
        WHERE EQUIP_CODE = p_equip_code
        AND OWN_END_DATE IS NULL;

        v_updated_count := SQL%ROWCOUNT;
        DBMS_OUTPUT.PUT_LINE('장비 코드 ' || p_equip_code || ' 비활성화 완료');
    ELSE
        -- 지연과 같은 일시적 문제는 매칭 건만 취소하고 스토렌은 그대로 유지
        DBMS_OUTPUT.PUT_LINE('지연 처리: 매칭 건만 취소됨');
    END IF;

    -- 5. 관련 사용자들에게 알림 발송
    FOR r IN (
        SELECT DISTINCT
            SMR.STOREN_MATCHING_REQ_USER_ID AS USER_CODE,
            CASE
                WHEN INSTR(p_reason, '지연') > 0 THEN 5 -- 댓글/렌탈댓글 블라인드(작성자) 알림 유형
                WHEN INSTR(p_reason, '손상') > 0 THEN 5 -- 댓글/렌탈댓글 블라인드(작성자) 알림 유형
                WHEN INSTR(p_reason, '분실') > 0 THEN 5 -- 댓글/렌탈댓글 블라인드(작성자) 알림 유형
                ELSE 5 -- 기타 이유 관련 알림 유형
            END AS NOTI_TYPE_ID
        FROM STOREN_MATCHING_REQ SMR
        JOIN STOREN_IRA SI ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
        JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
        WHERE S.EQUIP_CODE = p_equip_code
        AND SMR.STOREN_MATCHING_REQ_USER_ID IS NOT NULL
    ) LOOP
        INSERT INTO NOTI (
            NOTI_ID,
            USER_CODE,
            NOTI_TYPE_ID,
            CREATED_DATE
        ) VALUES (
            NOTI_SEQ.NEXTVAL,
            r.USER_CODE,
            r.NOTI_TYPE_ID,
            SYSDATE
        );
    END LOOP;

    -- 장비 소유자에게도 알림
    FOR r IN (
        SELECT ER.USER_CODE
        FROM EQUIPMENT_REGISTRATION ER
        WHERE ER.EQUIP_CODE = p_equip_code
    ) LOOP
        INSERT INTO NOTI (
            NOTI_ID,
            USER_CODE,
            NOTI_TYPE_ID,
            CREATED_DATE
        ) VALUES (
            NOTI_SEQ.NEXTVAL,
            r.USER_CODE,
            29, -- 사용자 문제 발생(소유자) 알림 유형
            SYSDATE
        );
    END LOOP;

    -- 로그 기록
    DBMS_OUTPUT.PUT_LINE('처리 완료. EQUIP_CODE NULL 처리된 스토렌 수: ' || v_updated_count);

    -- COMMIT 제거(트리거가 불러내는 해당 프로시저. 트리거 내부에서는 COMMIT과 ROLLBACK 허용 안 함.)
    -- COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        -- ROLLBACK 제거
        -- ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('오류 발생: ' || SQLERRM);
END PROC_CANCEL_EQUIPMENT_RENTALS;
/

