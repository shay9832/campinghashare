create view IR_STOREN as
SELECT IST.회원_코드, 장비등록_장비코드, 스토렌_ID, 결제_금액, 결제_일자, 결제_ID, 플랫폼_배송_ID, 배송_시작일, 배송_종료일, 플랫폼_배송_반환_ID, PS_배송_시작일, PS_배송_종료일, 검수리스트_ID
     ,IR.INSPEC_RESULT_ID AS 검수_결과_ID
FROM IL_STOREN IST JOIN INSPEC_RESULT IR
ON IST.플랫폼_배송_ID = IR.PLATFORM_DELIVERY_ID
/

