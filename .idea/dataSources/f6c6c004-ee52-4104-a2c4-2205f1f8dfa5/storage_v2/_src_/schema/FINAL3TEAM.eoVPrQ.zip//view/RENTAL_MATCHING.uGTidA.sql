create view RENTAL_MATCHING as
SELECT PR.회원_코드, 장비등록_장비코드, 렌탈_ID, 결제_금액, 결제_일자, 결제_ID, 렌탈_매칭_신청_ID, 매칭_렌탈_시작일, 매칭_렌탈_종료일, 렌탈_매칭_신청일
     ,RENTAL_MATCHING_DONE_ID AS 렌탈_매칭_완료_ID,APPROVED_DATE AS 승인_일자
FROM P_RENTAL PR JOIN RENTAL_MATCHING_DONE RMD
ON PR.렌탈_매칭_신청_ID = RMD.RENTAL_MATCHING_REQ_ID
/

