create trigger TRG_DELAYED_RETURN
    after update
    on PLATFORM_DELIVERY_RETURN
    for each row
DECLARE
    v_equip_code NUMBER;
    v_storen_matching_done_id NUMBER;
    v_expected_return_date DATE;
    v_actual_return_date DATE := :NEW.DELIVERY_END_DATE;
    v_delay_days NUMBER;
    v_threshold NUMBER := 3; -- 3일 이상 지연 시 문제로 간주
BEGIN
    -- 반납 완료된 경우만 처리 (DELIVERY_END_DATE가 설정된 경우)
    IF :OLD.DELIVERY_END_DATE IS NULL AND :NEW.DELIVERY_END_DATE IS NOT NULL THEN
        -- 장비 코드와, STOREN_MATCHING_DONE_ID, 예상 반납일 가져오기
        SELECT EC.EQUIP_CODE, SMD.STOREN_MATCHING_DONE_ID, SMR.RENTAL_END_DATE + 1 
        INTO v_equip_code, v_storen_matching_done_id, v_expected_return_date
        FROM PLATFORM_DELIVERY_RETURN PDR
        JOIN PLATFORM_DELIVERY PD ON PDR.PLATFORM_DELIVERY_ID = PD.PLATFORM_DELIVERY_ID
        JOIN PAY P ON PD.PAY_ID = P.PAY_ID
        JOIN STOREN_MATCHING_DONE SMD ON P.STOREN_MATCHING_DONE_ID = SMD.STOREN_MATCHING_DONE_ID
        JOIN STOREN_MATCHING_REQ SMR ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
        JOIN STOREN_IRA SI ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
        JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
        JOIN EQUIP_CODE EC ON S.EQUIP_CODE = EC.EQUIP_CODE
        WHERE PDR.PLATFORM_DELIVERY_RETURN_ID = :NEW.PLATFORM_DELIVERY_RETURN_ID;

        -- 지연 일수 계산
        v_delay_days := v_actual_return_date - v_expected_return_date;

        -- 지연이 임계값보다 큰 경우 처리
        IF v_delay_days > v_threshold THEN
            -- 지연 문제 로그 기록 (RENTER_PROBLEM_LOST 테이블에 기록 - 분실은 아니지만 지연 기록용으로 사용)
            INSERT INTO RENTER_PROBLEM_LOST (
                RENTER_PROBLEM_LOST_ID,
                STOREN_MATCHING_DONE_ID,
                PROBLEM_REPORTED_DATE
            ) VALUES (
                RENTER_PROBLEM_LOST_SEQ.NEXTVAL,
                v_storen_matching_done_id,
                SYSDATE
            );

            -- 해당 장비의 모든 활성 스토렌 및 예약 취소 프로시저 호출
            EXECUTE IMMEDIATE 'BEGIN PRC_CANCEL_EQUIPMENT_RENTALS(:1, :2, NULL); END;' 
            USING v_equip_code, '반납 지연으로 인한 취소 (지연일: ' || v_delay_days || '일)';
        END IF;
    END IF;
END;
/

