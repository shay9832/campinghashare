create view PAY_STORAGE as
SELECT US.보관_ID, US.장비등록_장비코드, US.회원_코드, P.PAY_AMOUNT AS 결제_금액, P.PAY_DATE AS 결제_일자, PAY_ID AS 결제_ID
FROM USER_STORAGE US JOIN PAY P
                          ON US.보관_ID = P.PAY_ID
/

