create view VW_SUSPENDED_USER_AND_ADMINS as
SELECT T."관리자회원코드",T."관리자ID",T."활동정지유저코드",T."활동정지시작일", CASE WHEN T."활동정지시작일" - SYSDATE >= 30 THEN '정지해제'
               ELSE '정지 중' END "활동정지상태"
FROM
(
     SELECT A.USER_CODE "관리자회원코드", A.ADMIN_ID "관리자ID"
     , SU.USER_CODE "활동정지유저코드", SU.SUSPENDED_START_DATE "활동정지시작일"
     FROM SUSPENDED_USER SU
     JOIN ADMINS A
     ON SU.ADMIN_ID = A.ADMIN_ID
) T
/

