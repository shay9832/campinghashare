create PROCEDURE INSPECT_RESULT (
    p_platform_delivery_id IN NUMBER,
    p_platform_delivery_return_id IN NUMBER,
    p_equip_grade_id IN NUMBER
) IS
        v_platform_delivery_id NUMBER;
        v_platform_delivery_return_id NUMBER;
        v_equip_grade_id NUMBER;
BEGIN
    SELECT PLATFORM_DELIVERY_ID INTO v_platform_delivery_id
    FROM PLATFORM_DELIVERY
    WHERE PLATFORM_DELIVERY_ID = 1;

    SELECT PLATFORM_DELIVERY_RETURN_ID INTO v_platform_delivery_return_id
    FROM PLATFORM_DELIVERY_RETURN
    WHERE PLATFORM_DELIVERY_RETURN_ID = 1;

    SELECT EQUIP_GRADE_ID INTO v_equip_grade_id
    FROM EQUIP_GRADE
    WHERE EQUIP_GRADE_ID = 1;

    INSERT INTO INSPEC_RESULT(inspec_result_id, platform_delivery_id, platform_delivery_return_id, equip_grade_id)
        VALUES(INSPEC_RESULT_SEQ.nextval,v_platform_delivery_id,v_platform_delivery_return_id,v_equip_grade_id);
end;
/

