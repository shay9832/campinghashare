create PROCEDURE INSPECT_RESULT (
    p_platform_delivery_id IN NUMBER,
    p_platform_delivery_return_id IN NUMBER,
    p_equip_grade_id IN NUMBER
) IS
    v_platform_delivery_id NUMBER := NULL;
    v_platform_delivery_return_id NUMBER := NULL;
    v_equip_grade_id NUMBER;
    v_record_exists NUMBER;
BEGIN
    -- 유효성 검사: 최소한 p_equip_grade_id는 필수
    IF p_equip_grade_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, '장비 등급 ID는 필수입니다.');
    END IF;

    -- 장비 등급 유효성 검사
    SELECT COUNT(*) INTO v_record_exists
    FROM EQUIP_GRADE
    WHERE EQUIP_GRADE_ID = p_equip_grade_id;

    IF v_record_exists = 0 THEN
        RAISE_APPLICATION_ERROR(-20002, '유효하지 않은 장비 등급 ID: ' || p_equip_grade_id);
    END IF;

    -- 배송 ID 유효성 검사 (제공된 경우)
    IF p_platform_delivery_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_record_exists
        FROM PLATFORM_DELIVERY
        WHERE PLATFORM_DELIVERY_ID = p_platform_delivery_id;

        IF v_record_exists > 0 THEN
            v_platform_delivery_id := p_platform_delivery_id;
        ELSE
            RAISE_APPLICATION_ERROR(-20003, '유효하지 않은 플랫폼 배송 ID: ' || p_platform_delivery_id);
        END IF;
    END IF;

    -- 배송 반환 ID 유효성 검사 (제공된 경우)
    IF p_platform_delivery_return_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_record_exists
        FROM PLATFORM_DELIVERY_RETURN
        WHERE PLATFORM_DELIVERY_RETURN_ID = p_platform_delivery_return_id;

        IF v_record_exists > 0 THEN
            v_platform_delivery_return_id := p_platform_delivery_return_id;
        ELSE
            RAISE_APPLICATION_ERROR(-20004, '유효하지 않은 플랫폼 배송 반환 ID: ' || p_platform_delivery_return_id);
        END IF;
    END IF;

    -- 배송 ID와 반환 ID 둘 다 NULL인 경우 확인
    IF v_platform_delivery_id IS NULL AND v_platform_delivery_return_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20005, '플랫폼 배송 ID 또는 플랫폼 배송 반환 ID 중 하나는 필수입니다.');
    END IF;

    -- 데이터 삽입
    INSERT INTO INSPEC_RESULT(
        inspec_result_id,
        platform_delivery_id,
        platform_delivery_return_id,
        equip_grade_id
    ) VALUES (
                 INSPEC_RESULT_SEQ.nextval,
                 v_platform_delivery_id,
                 v_platform_delivery_return_id,
                 p_equip_grade_id
             );

    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        -- 롤백 및 오류 메시지 기록
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('오류 발생: ' || SQLERRM);
        RAISE;
END INSPECT_RESULT;
/

