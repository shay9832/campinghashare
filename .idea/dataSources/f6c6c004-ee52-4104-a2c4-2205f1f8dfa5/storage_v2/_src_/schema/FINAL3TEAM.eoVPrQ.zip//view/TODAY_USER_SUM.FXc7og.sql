create view TODAY_USER_SUM as
SELECT TPA.회원_코드, 스토렌_ID, 스토렌_매칭_완료_ID, 스토렌_결제_금액, 보관_결제_금액, 보관_결제_일자, 렌탈_결제_금액, 렌탈_결제_일자
        ,UC.CREATED_DATE AS 회원가입일
FROM USER_COUNT UC JOIN TODAY_PRICE_ALL TPA
ON UC.회원_코드 = TPA.회원_코드
/

