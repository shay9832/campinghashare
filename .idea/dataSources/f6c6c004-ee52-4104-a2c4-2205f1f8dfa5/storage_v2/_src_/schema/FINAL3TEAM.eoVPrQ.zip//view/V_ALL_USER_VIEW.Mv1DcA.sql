create view V_ALL_USER_VIEW as
SELECT VTW.회원_코드, 스토렌_ID, 스토렌_매칭_완료_ID, 스토렌_결제_금액, 보관_결제_금액, 보관_결제_일자, 렌탈_결제_금액, 렌탈_결제_일자, 회원가입일, 검수_결과_ID, 검수_결과_처리일, 게시글_신고접수_ID, 게시글_신고일, 댓글_신고_접수_ID, 댓글_신고일, 렌탈_댓글_신고_접수_ID, 렌탈_댓글_신고일
        , U.USER_ID AS 회원_ID
FROM V_TODAY_USER_WARRING VTW JOIN USERS U
ON VTW.회원_코드 = U.USER_CODE
/

