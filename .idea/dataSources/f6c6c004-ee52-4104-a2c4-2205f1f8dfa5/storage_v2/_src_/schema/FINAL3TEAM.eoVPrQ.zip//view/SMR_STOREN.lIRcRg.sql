create view SMR_STOREN as
SELECT IST.회원_코드, 장비등록_장비코드, 스토렌_ID, 결제_금액, 결제_일자, 결제_ID, 플랫폼_배송_ID, 배송_시작일, 배송_종료일, 플랫폼_배송_반환_ID, PS_배송_시작일, PS_배송_종료일, 검수리스트_ID, 검수_결과_ID, 검수_결과_처리_ID
     ,STOREN_MATCHING_REQ_ID AS 스토렌_매칭_신청_ID,RENTAL_START_DATE AS 렌탈_시작일,RENTAL_END_DATE AS 렌탈_종료일,REQUESTED_DATE AS 신청일
FROM IRA_STOREN IST JOIN STOREN_MATCHING_REQ SMR
                         ON IST.검수_결과_처리_ID = SMR.STOREN_IRA_ID
/

