create view RENTAL_REPLY_ACTION_SUM as
SELECT RRS.회원코드, 렌탈_신고접수자_ID, 렌탈_댓글_ID, 렌탈_댓글_신고_유형_ID, 렌탈_댓글_신고_내용, 렌탈_댓글_신고일, 렌탈_댓글_신고_접수_ID
     ,RRRA.ADMIN_ID AS 렌탈_처리_관리자_ID,RRRA.REPORT_ACTION_TYPE_ID AS 렌탈_댓글_처리_유형_ID,RRRA.COMPLETED_DATE AS 렌탈_댓글_신고_처리일
FROM RENTAL_REPLY_SUM RRS JOIN RENTAL_REPLY_REPORT_ACTION RRRA
                               ON RRS.렌탈_댓글_신고_접수_ID = RRRA.RENTAL_REPLY_REPORT_ID
/

