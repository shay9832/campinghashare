create view VW_STOREN_STATUS_DETAIL as
SELECT 
    S.STOREN_ID,
    S.EQUIP_CODE,
    ER.USER_CODE,
    S.STOREN_TITLE,
    S.CREATED_DATE,
    CASE
        WHEN NOT EXISTS (SELECT 1 FROM PAY P WHERE P.STOREN_ID = S.STOREN_ID) 
            THEN '보관비 결제 대기'
        WHEN EXISTS (SELECT 1 FROM PAY P WHERE P.STOREN_ID = S.STOREN_ID)
             AND NOT EXISTS (SELECT 1 FROM PLATFORM_DELIVERY PD JOIN PAY P ON PD.PAY_ID = P.PAY_ID WHERE P.STOREN_ID = S.STOREN_ID)
            THEN '배송 대기'
        WHEN EXISTS (SELECT 1 FROM PLATFORM_DELIVERY PD 
                     JOIN PAY P 
                          ON PD.PAY_ID = P.PAY_ID 
                     WHERE P.STOREN_ID = S.STOREN_ID 
                     AND PD.DELIVERY_START_DATE IS NOT NULL 
                     AND PD.DELIVERY_END_DATE IS NULL)
            THEN '배송 중'
        WHEN EXISTS (SELECT 1 FROM PLATFORM_DELIVERY PD 
                     JOIN PAY P 
                          ON PD.PAY_ID = P.PAY_ID 
                     WHERE P.STOREN_ID = S.STOREN_ID 
                     AND PD.DELIVERY_END_DATE IS NOT NULL)
             AND NOT EXISTS (SELECT 1 FROM INSPEC_RESULT IR 
                            JOIN PLATFORM_DELIVERY PD 
                                 ON IR.PLATFORM_DELIVERY_ID = PD.PLATFORM_DELIVERY_ID
                            JOIN PAY P 
                                 ON PD.PAY_ID = P.PAY_ID 
                            WHERE P.STOREN_ID = S.STOREN_ID)
            THEN '검수 중'
        WHEN EXISTS (SELECT 1 FROM STOREN_IRA SI WHERE SI.STOREN_ID = S.STOREN_ID)
             AND NOT EXISTS (SELECT 1 FROM STOREN_MATCHING_REQ SMR 
                            JOIN STOREN_IRA SI 
                                 ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
                            WHERE SI.STOREN_ID = S.STOREN_ID)
            THEN '보관 중'
        WHEN EXISTS (SELECT 1 FROM STOREN_MATCHING_REQ SMR 
                     JOIN STOREN_IRA SI 
                          ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
                     WHERE SI.STOREN_ID = S.STOREN_ID)
             AND NOT EXISTS (SELECT 1 FROM STOREN_MATCHING_DONE SMD 
                            JOIN STOREN_MATCHING_REQ SMR 
                                 ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
                            JOIN STOREN_IRA SI 
                                 ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                            WHERE SI.STOREN_ID = S.STOREN_ID)
            THEN '승인 대기'
        WHEN EXISTS (SELECT 1 FROM STOREN_MATCHING_DONE SMD 
                     JOIN STOREN_MATCHING_REQ SMR 
                          ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
                     JOIN STOREN_IRA SI 
                          ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                     WHERE SI.STOREN_ID = S.STOREN_ID)
             AND NOT EXISTS (SELECT 1 FROM PAY P 
                            WHERE P.STOREN_MATCHING_DONE_ID IN 
                            (SELECT SMD.STOREN_MATCHING_DONE_ID FROM STOREN_MATCHING_DONE SMD 
                             JOIN STOREN_MATCHING_REQ SMR 
                                  ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
                             JOIN STOREN_IRA SI 
                                  ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                             WHERE SI.STOREN_ID = S.STOREN_ID))
            THEN '결제 대기'
        WHEN EXISTS (SELECT 1 FROM PAY P 
                    WHERE P.STOREN_MATCHING_DONE_ID IN 
                    (SELECT SMD.STOREN_MATCHING_DONE_ID FROM STOREN_MATCHING_DONE SMD 
                     JOIN STOREN_MATCHING_REQ SMR 
                          ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
                     JOIN STOREN_IRA SI 
                          ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                     WHERE SI.STOREN_ID = S.STOREN_ID))
             AND EXISTS (SELECT 1 FROM STOREN_MATCHING_REQ SMR 
                        JOIN STOREN_IRA SI 
                             ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                        WHERE SI.STOREN_ID = S.STOREN_ID 
                        AND SMR.RENTAL_END_DATE >= TRUNC(SYSDATE))
             AND NOT EXISTS (SELECT 1 FROM PLATFORM_DELIVERY_RETURN PDR 
                            WHERE PDR.PLATFORM_DELIVERY_ID IN 
                            (SELECT PD.PLATFORM_DELIVERY_ID FROM PLATFORM_DELIVERY PD 
                             JOIN PAY P 
                                  ON PD.PAY_ID = P.PAY_ID
                             WHERE P.STOREN_MATCHING_DONE_ID IN 
                             (SELECT SMD.STOREN_MATCHING_DONE_ID FROM STOREN_MATCHING_DONE SMD 
                              JOIN STOREN_MATCHING_REQ SMR 
                                   ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
                              JOIN STOREN_IRA SI 
                                   ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                              WHERE SI.STOREN_ID = S.STOREN_ID)))
            THEN '렌탈 중'
        WHEN EXISTS (SELECT 1 FROM PLATFORM_DELIVERY_RETURN PDR 
                    WHERE PDR.PLATFORM_DELIVERY_ID IN 
                    (SELECT PD.PLATFORM_DELIVERY_ID FROM PLATFORM_DELIVERY PD 
                     JOIN PAY P 
                          ON PD.PAY_ID = P.PAY_ID
                     WHERE P.STOREN_MATCHING_DONE_ID IN 
                     (SELECT SMD.STOREN_MATCHING_DONE_ID FROM STOREN_MATCHING_DONE SMD 
                      JOIN STOREN_MATCHING_REQ SMR 
                           ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
                      JOIN STOREN_IRA SI 
                           ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                      WHERE SI.STOREN_ID = S.STOREN_ID))
                    AND PDR.DELIVERY_END_DATE IS NULL)
            OR EXISTS (SELECT 1 FROM STOREN_MATCHING_REQ SMR 
                      JOIN STOREN_IRA SI 
                           ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID 
                      WHERE SI.STOREN_ID = S.STOREN_ID 
                      AND SMR.RENTAL_END_DATE <= TRUNC(SYSDATE))
            THEN '반납 중'
        ELSE '상태 불명'
    END AS STATUS
FROM STOREN S
JOIN EQUIPMENT_REGISTRATION ER
ON S.EQUIP_CODE = ER.EQUIP_CODE
/

