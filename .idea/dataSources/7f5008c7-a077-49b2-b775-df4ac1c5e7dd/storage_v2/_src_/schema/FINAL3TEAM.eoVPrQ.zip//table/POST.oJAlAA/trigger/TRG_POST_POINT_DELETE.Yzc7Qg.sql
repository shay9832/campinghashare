create trigger TRG_POST_POINT_DELETE
    after delete
    on POST
    for each row
DECLARE
    V_ADMIN_USER_CODE NUMBER;
BEGIN
    -- 관리자 여부 확인(USER_CODE가 관리자 테이블에 존재하는지 확인)
    SELECT USER_CODE INTO V_ADMIN_USER_CODE
    FROM ADMINS
    WHERE USER_CODE = :OLD.USER_CODE;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
    -- 관리자가 아닐 경우 포인트 차감
    INSERT INTO POINT_LOG (POINT_LOG_ID, USER_CODE, POINT_CHANGE_TYPE_ID, POINT_CHANGE, CREATED_DATE)
    VALUES (POINT_LOG_SEQ.nextval, :OLD.USER_CODE, (SELECT POINT_CHANGE_TYPE_ID
                                                                 FROM POINT_CHANGE_TYPE
                                                                 WHERE POINT_CHANGE_TYPE_NAME = '게시글 삭제'), -1, SYSDATE);
END;
/

