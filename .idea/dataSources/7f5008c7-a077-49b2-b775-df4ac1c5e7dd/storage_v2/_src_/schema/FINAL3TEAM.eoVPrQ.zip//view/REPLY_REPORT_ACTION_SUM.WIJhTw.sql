create view REPLY_REPORT_ACTION_SUM as
SELECT RRS.회원코드, 댓글신고접수자, 댓글_ID, 신고_유형_ID, 댓글_신고_내용, 신고일, 댓글_신고_접수_ID
        ,RRA.REPLY_REPORT_ACTION_ID AS 댓글_신고처리_ID,RRA.REPORT_ACTION_TYPE_ID AS 댓글_신고_처리_유형_ID,RRA.COMPLETED_DATE AS 댓글_신고_처리일
        ,RRA.ADMIN_ID AS 댓글_처리_관리자_ID
FROM REPLY_REPORT_SUM RRS JOIN REPLY_REPORT_ACTION RRA
ON RRS.댓글_신고_접수_ID = RRA.REPLY_REPORT_ID
/

