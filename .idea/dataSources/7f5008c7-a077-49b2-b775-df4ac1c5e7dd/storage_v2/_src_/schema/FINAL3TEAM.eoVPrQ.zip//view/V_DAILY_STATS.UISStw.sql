create view V_DAILY_STATS as
WITH
-- 일일 신규 사용자 수
신규회원 AS (
    SELECT COUNT(DISTINCT 회원_코드) AS 신규회원수
    FROM V_ALL_USER_VIEW
    WHERE TRUNC(회원가입일) = TRUNC(SYSDATE)
),

-- 거래 건수 및 금액
거래통계 AS (
    SELECT
        COUNT(CASE WHEN 스토렌_결제_금액 IS NOT NULL AND TRUNC(보관_결제_일자) = TRUNC(SYSDATE) THEN 1 END) AS 스토렌결제수,
        SUM(CASE WHEN TRUNC(보관_결제_일자) = TRUNC(SYSDATE) THEN NVL(스토렌_결제_금액, 0) ELSE 0 END) AS 스토렌결제액,

        COUNT(CASE WHEN 보관_결제_금액 IS NOT NULL AND TRUNC(보관_결제_일자) = TRUNC(SYSDATE) THEN 1 END) AS 보관결제수,
        SUM(CASE WHEN TRUNC(보관_결제_일자) = TRUNC(SYSDATE) THEN NVL(보관_결제_금액, 0) ELSE 0 END) AS 보관결제액,

        COUNT(CASE WHEN 렌탈_결제_금액 IS NOT NULL AND TRUNC(렌탈_결제_일자) = TRUNC(SYSDATE) THEN 1 END) AS 렌탈결제수,
        SUM(CASE WHEN TRUNC(렌탈_결제_일자) = TRUNC(SYSDATE) THEN NVL(렌탈_결제_금액, 0) ELSE 0 END) AS 렌탈결제액
    FROM V_ALL_USER_VIEW
),

-- 검수 건수
검수통계 AS (
    SELECT COUNT(DISTINCT 검수_결과_ID) AS 검수건수
    FROM V_ALL_USER_VIEW
    WHERE 검수_결과_ID IS NOT NULL
      AND TRUNC(검수_결과_처리일) = TRUNC(SYSDATE)
),

-- 신고 건수
신고통계 AS (
    SELECT
        COUNT(CASE WHEN 게시글_신고접수_ID IS NOT NULL AND TRUNC(게시글_신고일) = TRUNC(SYSDATE) THEN 1 END) AS 게시글신고수,
        COUNT(CASE WHEN 댓글_신고_접수_ID IS NOT NULL AND TRUNC(댓글_신고일) = TRUNC(SYSDATE) THEN 1 END) AS 댓글신고수,
        COUNT(CASE WHEN 렌탈_댓글_신고_접수_ID IS NOT NULL AND TRUNC(렌탈_댓글_신고일) = TRUNC(SYSDATE) THEN 1 END) AS 렌탈댓글신고수
    FROM V_ALL_USER_VIEW
),

-- 총 회원 수
총회원 AS (
    SELECT COUNT(DISTINCT 회원_코드) AS 총회원수
    FROM V_ALL_USER_VIEW
)

-- 합치기
SELECT
    신규회원.신규회원수,

    거래통계.스토렌결제수,
    거래통계.스토렌결제액,
    거래통계.보관결제수,
    거래통계.보관결제액,
    거래통계.렌탈결제수,
    거래통계.렌탈결제액,

    -- 합계 계산
    (거래통계.스토렌결제수 + 거래통계.보관결제수 + 거래통계.렌탈결제수) AS 총결제건수,
    (거래통계.스토렌결제액 + 거래통계.보관결제액 + 거래통계.렌탈결제액) AS 총결제금액,

    검수통계.검수건수,

    신고통계.게시글신고수,
    신고통계.댓글신고수,
    신고통계.렌탈댓글신고수,
    (신고통계.게시글신고수 + 신고통계.댓글신고수 + 신고통계.렌탈댓글신고수) AS 총신고건수,

    총회원.총회원수,

    SYSDATE AS 집계일자
FROM
    신규회원,
    거래통계,
    검수통계,
    신고통계,
    총회원
/

