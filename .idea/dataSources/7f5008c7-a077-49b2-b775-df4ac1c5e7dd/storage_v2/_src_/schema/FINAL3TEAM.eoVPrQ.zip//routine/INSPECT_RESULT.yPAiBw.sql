create PROCEDURE INSPECT_RESULT

(
    P_PLATFORM_DELIVERY_ID IN NUMBER,
    P_PLATFORM_DELIVERY_RETURN_ID IN NUMBER,
    P_INSPEC_GRADE_ID IN NUMBER,
    P_EQUIP_GRADE_ID IN NUMBER,
    P_ADMIN_ID IN VARCHAR2 DEFAULT 'ADMIN1'
)
AS
    V_INSPEC_LIST_ID NUMBER;
    V_INSPEC_RESULT_ID NUMBER;
    V_STOREN_ID NUMBER;
    V_INSPEC_RESULT_ACTION_ID NUMBER;
    V_RESULT_ACTION_TYPE_ID NUMBER;
    V_CATE_INSPEC_ID NUMBER;
    V_EXISTING_COUNT NUMBER := 0;
    V_EQUIP_GRADE_NAME CHAR(1);
    V_IS_RETURN BOOLEAN := FALSE;
    V_PLATFORM_DELIVERY_ID NUMBER := P_PLATFORM_DELIVERY_ID; -- 임시 변수로 값을 복사
    V_USER_RETURN_ID NUMBER; -- 사용자 반납 ID
    V_EQUIPMENT_ID NUMBER; -- 장비 ID
    V_PAY_ID NUMBER; -- 결제 ID
    V_RETURN_STATUS_ID NUMBER := 1; -- 반납 상태 ID (기본값 1: 반납 요청)
BEGIN
    -- 기본 검증: 최소한 하나의 ID는 제공되어야 함
    IF P_PLATFORM_DELIVERY_ID IS NULL AND P_PLATFORM_DELIVERY_RETURN_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20000, '배송 ID 또는 반환 ID가 제공되어야 합니다.');
    END IF;

    -- 필수 매개변수 검증
    IF P_INSPEC_GRADE_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20003, '검수 등급 ID는 필수입니다.');
    END IF;

    IF P_EQUIP_GRADE_ID IS NULL THEN
        RAISE_APPLICATION_ERROR(-20004, '장비 등급 ID는 필수입니다.');
    END IF;

    -- 반환검수인지 일반검수인지 확인
    IF P_PLATFORM_DELIVERY_RETURN_ID IS NOT NULL THEN
        V_IS_RETURN := TRUE;

        -- 반환검수의 경우 원본 배송 ID도 필요한지 검증
        IF V_PLATFORM_DELIVERY_ID IS NULL THEN
            -- 원본 배송 ID가 없는 경우 조회 시도
            BEGIN
                SELECT PLATFORM_DELIVERY_ID INTO V_PLATFORM_DELIVERY_ID
                FROM PLATFORM_DELIVERY_RETURN
                WHERE PLATFORM_DELIVERY_RETURN_ID = P_PLATFORM_DELIVERY_RETURN_ID;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20005, '반환 ID에 대응하는 배송 ID를 찾을 수 없습니다: ' || P_PLATFORM_DELIVERY_RETURN_ID);
            END;
        END IF;
    END IF;

    -- 이미 검수 처리가 되었는지 확인
    IF V_IS_RETURN THEN
        -- 반환검수 경우
        SELECT COUNT(*) INTO V_EXISTING_COUNT
        FROM INSPEC_RESULT
        WHERE PLATFORM_DELIVERY_RETURN_ID = P_PLATFORM_DELIVERY_RETURN_ID;
    ELSE
        -- 일반검수 경우
        SELECT COUNT(*) INTO V_EXISTING_COUNT
        FROM INSPEC_RESULT
        WHERE PLATFORM_DELIVERY_ID = V_PLATFORM_DELIVERY_ID
          AND PLATFORM_DELIVERY_RETURN_ID IS NULL;
    END IF;

    -- 이미 처리된 경우 예외 발생
    IF V_EXISTING_COUNT > 0 THEN
        RAISE_APPLICATION_ERROR(-20001, '이미 검수 처리가 완료된 항목입니다.');
    END IF;

    -- EQUIP_GRADE 테이블에서 등급 정보 가져오기
    BEGIN
        SELECT EQUIP_GRADE_NAME INTO V_EQUIP_GRADE_NAME
        FROM EQUIP_GRADE
        WHERE EQUIP_GRADE_ID = P_EQUIP_GRADE_ID;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20002, '유효하지 않은 장비 등급 ID: ' || P_EQUIP_GRADE_ID);
    END;

    -- 관련 카테고리 검수 항목 ID 가져오기
    BEGIN
        -- 카테고리 검수 항목 ID 가져오기 (반환검수와 일반검수에 따라 달라질 수 있음)
        IF V_IS_RETURN THEN
            -- 반환검수에 적합한 카테고리 ID 찾기 (필요시 수정)
            SELECT MIN(CATE_INSPEC_ID) INTO V_CATE_INSPEC_ID FROM CATE_INSPEC;
        ELSE
            -- 일반검수에 적합한 카테고리 ID 찾기 (필요시 수정)
            SELECT MIN(CATE_INSPEC_ID) INTO V_CATE_INSPEC_ID FROM CATE_INSPEC;
        END IF;

        IF V_CATE_INSPEC_ID IS NULL THEN
            V_CATE_INSPEC_ID := 1; -- 기본값 설정
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_CATE_INSPEC_ID := 1; -- 기본값 설정
    END;

    -- 1. 검수 목록 테이블에 데이터 저장 (검수 시작)
    -- BEGIN
    --     SELECT NVL(MAX(INSPEC_LIST_ID), 0) + 1 INTO V_INSPEC_LIST_ID FROM INSPEC_LIST;

    --     INSERT INTO INSPEC_LIST
    --     (INSPEC_LIST_ID, INSPEC_COMMENT, CATE_INSPEC_ID, PLATFORM_DELIVERY_ID,
    --      PLATFORM_DELIVERY_RETURN_ID, ADMIN_ID, INSPEC_GRADE_ID, INSPECTION_DATE)
    --     VALUES
    --         (V_INSPEC_LIST_ID, P_INSPEC_COMMENT, V_CATE_INSPEC_ID,
    --          V_PLATFORM_DELIVERY_ID, P_PLATFORM_DELIVERY_RETURN_ID,
    --          P_ADMIN_ID, P_INSPEC_GRADE_ID, SYSDATE);
    -- EXCEPTION
    --     WHEN OTHERS THEN
    --         RAISE_APPLICATION_ERROR(-20006, '검수 목록 저장 중 오류 발생: ' || SQLERRM);
    -- END;

    -- 2. 검수 결과 테이블에 데이터 저장 (검수 완료)
    BEGIN
        SELECT NVL(MAX(INSPEC_RESULT_ID), 0) + 1 INTO V_INSPEC_RESULT_ID FROM INSPEC_RESULT;

        -- 반환검수인 경우와 일반검수인 경우를 분리
        IF V_IS_RETURN THEN
            -- 반환검수의 경우 PLATFORM_DELIVERY_ID를 NULL로 설정
            INSERT INTO INSPEC_RESULT
            (INSPEC_RESULT_ID, PLATFORM_DELIVERY_ID, PLATFORM_DELIVERY_RETURN_ID, EQUIP_GRADE_ID)
            VALUES
                (V_INSPEC_RESULT_ID, NULL, P_PLATFORM_DELIVERY_RETURN_ID, P_EQUIP_GRADE_ID);
        ELSE
            -- 일반검수의 경우 PLATFORM_DELIVERY_RETURN_ID를 NULL로 유지
            INSERT INTO INSPEC_RESULT
            (INSPEC_RESULT_ID, PLATFORM_DELIVERY_ID, PLATFORM_DELIVERY_RETURN_ID, EQUIP_GRADE_ID)
            VALUES
                (V_INSPEC_RESULT_ID, V_PLATFORM_DELIVERY_ID, NULL, P_EQUIP_GRADE_ID);
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20007, '검수 결과 저장 중 오류 발생: ' || SQLERRM);
    END;

    -- 3. 등급에 따른 처리 유형 결정 (EQUIP_GRADE 정보 기반)
    IF V_EQUIP_GRADE_NAME IN ('A', 'B', 'C', 'D', 'E') THEN
        V_RESULT_ACTION_TYPE_ID := 1; -- 스토렌 입고
    ELSE
        V_RESULT_ACTION_TYPE_ID := 3; -- 강제 반환환 (F 등급만)
    END IF;

    -- 4. 검수 결과 처리 테이블에 데이터 저장
    BEGIN
        SELECT NVL(MAX(INSPEC_RESULT_ACTION_ID), 0) + 1 INTO V_INSPEC_RESULT_ACTION_ID FROM INSPEC_RESULT_ACTION;

        INSERT INTO INSPEC_RESULT_ACTION
        (INSPEC_RESULT_ACTION_ID, INSPEC_RESULT_ID, INSPEC_RESULT_ACTION_TYPE_ID, COMPLETED_DATE)
        VALUES
            (V_INSPEC_RESULT_ACTION_ID, V_INSPEC_RESULT_ID, V_RESULT_ACTION_TYPE_ID, SYSDATE);
    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20008, '검수 결과 처리 저장 중 오류 발생: ' || SQLERRM);
    END;

    -- 5. 검수 결과 처리 이후 스토렌 검수결과 처리에 데이터 저장
    BEGIN
        SELECT S.STOREN_ID INTO V_STOREN_ID
        FROM STOREN S
                 JOIN PAY P ON S.STOREN_ID = P.STOREN_ID
                 JOIN PLATFORM_DELIVERY PD ON P.PAY_ID = PD.PAY_ID
                 JOIN INSPEC_LIST IL ON PD.PLATFORM_DELIVERY_ID = IL.PLATFORM_DELIVERY_ID
                 JOIN INSPEC_RESULT IR ON IL.PLATFORM_DELIVERY_ID = IR.PLATFORM_DELIVERY_ID
                 JOIN INSPEC_RESULT_ACTION IRA ON IR.INSPEC_RESULT_ID = IRA.INSPEC_RESULT_ID
        WHERE IRA.INSPEC_RESULT_ACTION_ID = V_INSPEC_RESULT_ACTION_ID;

        INSERT INTO STOREN_IRA
        (STOREN_IRA_ID, INSPEC_RESULT_ACTION_ID, STOREN_ID)
        VALUES
            (STOREN_IRA_SEQ.nextval, V_INSPEC_RESULT_ACTION_ID, V_STOREN_ID);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            -- 오류 처리를 위한 예외 처리 블록만 추가, 실패해도 프로시저가 중단되지 않도록 함
            NULL;
        WHEN OTHERS THEN
            -- 로그 테이블에 오류 기록 또는 다른 처리 가능
            NULL;
    END;

    -- 6. E 또는 F 등급(V_RESULT_ACTION_TYPE_ID = 3)인 경우 사용자 반납 처리
    IF V_RESULT_ACTION_TYPE_ID = 3 THEN
        BEGIN
            -- 필요한 정보 가져오기 (장비 ID, 결제 ID 등)
            BEGIN
                SELECT
                    ER.EQUIP_ID,
                    P.PAY_ID
                INTO
                    V_EQUIPMENT_ID,
                    V_PAY_ID
                FROM PLATFORM_DELIVERY PD
                         JOIN PAY P ON PD.PAY_ID = P.PAY_ID
                         JOIN EQUIPMENT_REGISTRATION ER ON (P.STOREN_ID = ER.EQUIP_ID OR P.STORAGE_ID = ER.EQUIP_ID)
                WHERE PD.PLATFORM_DELIVERY_ID = V_PLATFORM_DELIVERY_ID;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    -- 필요한 정보를 찾지 못할 경우 로깅만 하고 진행
                    NULL;
                WHEN OTHERS THEN
                    NULL;
            END;

            -- STOREN_LAST_RETURN 테이블에 데이터 추가
            IF V_STOREN_ID IS NOT NULL THEN
                INSERT INTO STOREN_LAST_RETURN
                (STOREN_LAST_RETURN_ID, STOREN_ID, INSPEC_RESULT_ACTION_ID, DELIVERY_START_DATE, DELIVERY_END_DATE)
                VALUES
                    (NVL((SELECT MAX(STOREN_LAST_RETURN_ID) FROM STOREN_LAST_RETURN), 0) + 1,
                     V_STOREN_ID, V_INSPEC_RESULT_ACTION_ID, SYSDATE, SYSDATE + 7); -- 배송 완료일은 7일 후로 가정
            END IF;

            -- 필요한 경우 INSPEC_LIST 테이블의 INSPEC_COMMENT 업데이트
            UPDATE INSPEC_LIST
            SET INSPEC_COMMENT = INSPEC_COMMENT || ' (사용자반납 처리됨)'
            WHERE INSPEC_LIST_ID = V_INSPEC_LIST_ID;
        EXCEPTION
            WHEN OTHERS THEN
                -- 사용자 반납 처리 실패해도 전체 프로시저는 계속 진행
                NULL;
        END;
    END IF;

    -- 트랜잭션 커밋
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        -- 롤백
        ROLLBACK;
        -- 오류 다시 발생
        RAISE;
END INSPECT_RESULT;
/

