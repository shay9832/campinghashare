create trigger TRG_USER_SIGNUP_COUPON
    after insert
    on USER_CODE
    for each row
BEGIN
    -- 새 회원에게 축하 쿠폰 지급 (ISSUED_COUPON_ID = 2 고정)
    INSERT INTO OWNED_COUPON (
        OWNED_COUPON_ID,
        USER_CODE,
        ISSUED_COUPON_ID,
        COMPLETED_DATE
    ) VALUES (
                 OWNED_COUPON_SEQ.NEXTVAL,
                 :NEW.USER_CODE,
                 2,  -- 고정된 회원가입 축하 쿠폰 ID
                 NULL  -- 아직 사용되지 않은 쿠폰이므로 COMPLETED_DATE는 NULL
             );

EXCEPTION
    WHEN OTHERS THEN
        -- 오류 발생 시 로깅 (실패해도 회원가입 자체는 계속 진행)
        DBMS_OUTPUT.PUT_LINE('쿠폰 지급 중 오류 발생: ' || SQLERRM);
END;
/

