create view VW_USER_WITH_POINT_TRUST as
WITH LATEST_NICKNAME AS (
    -- 각 유저의 가장 최근 닉네임 조회
    SELECT 
        USER_CODE,
        NICKNAME
    FROM (
        SELECT 
            USER_CODE,
            NICKNAME,
            ROW_NUMBER() OVER (PARTITION BY USER_CODE ORDER BY LAST_UPDATED_DATE DESC) AS RN
        FROM 
            NICKNAME_LOG
    ) 
    WHERE RN = 1
),
LATEST_ADDRESS AS (
    -- 각 유저의 가장 최근 주소 조회
    SELECT 
        USER_CODE,
        ZIPCODE,
        ADDRESS1,
        ADDRESS2
    FROM (
        SELECT 
            USER_CODE,
            ZIPCODE,
            ADDRESS1,
            ADDRESS2,
            ROW_NUMBER() OVER (PARTITION BY USER_CODE ORDER BY LAST_UPDATED_DATE DESC) AS RN
        FROM 
            ADDRESS_LOG
    ) 
    WHERE RN = 1
),
TOTAL_POINTS AS (
    -- 각 유저의 누적 포인트 계산
    SELECT 
        USER_CODE,
        NVL(SUM(POINT_CHANGE), 0) AS ACCUMULATED_POINTS
    FROM 
        POINT_LOG
    GROUP BY 
        USER_CODE
),
TRUST_SCORE AS (
    -- 각 유저의 신뢰도 계산
    SELECT 
        REVIEWEE_ID AS USER_CODE,
        50 + NVL(SUM(
            CASE 
                WHEN SATIS_SCORE = 5 THEN 3
                WHEN SATIS_SCORE = 4 THEN 1.5
                WHEN SATIS_SCORE = 3 THEN 0
                WHEN SATIS_SCORE = 2 THEN -3
                WHEN SATIS_SCORE = 1 THEN -5
                ELSE 0
            END
        ), 0) AS TRUST_SCORE
    FROM 
        SATISFACTION_LOG
    GROUP BY 
        REVIEWEE_ID
),
TOTAL_PROFIT AS (
     -- 각 유저의 총 수익 계산
     SELECT "소유자회원코드" AS "USER_CODE",
          NVL(SUM("결제금액"), 0) AS "TOTAL_PROFIT"
     FROM (
          SELECT "소유자회원코드",
               "결제금액"
          FROM VW_STOREN_AND_PAY
          WHERE "결제여부" = '결제완료'

          UNION ALL

          SELECT "소유자회원코드", 
               "결제금액"
          FROM VW_RENTAL_AND_PAY
          WHERE "결제여부" = '결제완료'
     )
     GROUP BY "소유자회원코드"
)
SELECT 
     U.USER_CODE
     , U.USER_ID
     , U.USER_PW
     , U.USER_NAME
     , U.USER_TEL
     , NVL(U.USER_EMAIL, '미입력') AS USER_EMAIL
     , CASE
       WHEN U.EMAIL_CONSENT = 1 THEN '동의'
       ELSE '미동의'
       END AS EMAIL_CONSENT
     , TO_CHAR(U.CREATED_DATE, 'YYYY-MM-DD') AS JOIN_DATE
     , LN.NICKNAME AS CURRENT_NICKNAME
     , NVL(TP.ACCUMULATED_POINTS, 0) AS TOTAL_POINTS
     , CASE
       WHEN NVL(TS.TRUST_SCORE, 50) > 100 THEN 100
       WHEN NVL(TS.TRUST_SCORE, 50) < 0 THEN 0
       ELSE NVL(TS.TRUST_SCORE, 50)
       END AS TRUST_SCORE
     , LA.ZIPCODE
     , LA.ADDRESS1
     , LA.ADDRESS2
     , R.RANK_NAME AS USER_GRADE
     , R.MAX_NICKNAME_CHANGE AS ALLOWED_NICKNAME_CHANGE
     , TP.TOTAL_PROFIT
FROM 
    USERS U
    LEFT JOIN LATEST_NICKNAME LN ON U.USER_CODE = LN.USER_CODE
    LEFT JOIN TOTAL_POINTS TP ON U.USER_CODE = TP.USER_CODE
    LEFT JOIN TRUST_SCORE TS ON U.USER_CODE = TS.USER_CODE
    LEFT JOIN LATEST_ADDRESS LA ON U.USER_CODE = LA.USER_CODE
    LEFT JOIN TOTAL_PROFIT TP ON U.USER_CODE = TP.USER_CODE
    LEFT JOIN RANK R 
    ON NVL(TP.ACCUMULATED_POINTS, 0) BETWEEN R.MIN_POINT AND R.MAX_POINT
    AND CASE
           WHEN NVL(TS.TRUST_SCORE, 50) > 100 THEN 100
           WHEN NVL(TS.TRUST_SCORE, 50) < 0 THEN 0
           ELSE NVL(TS.TRUST_SCORE, 50)
       END BETWEEN R.MIN_CREDIT AND R.MAX_CREDIT
/

