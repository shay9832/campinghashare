create trigger TR_DELIVERY_RETURN
    after insert
    on PLATFORM_DELIVERY
    for each row
BEGIN
    -- PLATFORM_DELIVERY_RETURN 테이블에 데이터 삽입
    INSERT INTO PLATFORM_DELIVERY_RETURN (
        PLATFORM_DELIVERY_RETURN_ID,  -- 반환 ID
        PLATFORM_DELIVERY_ID,         -- 원본 배송 ID
        DELIVERY_START_DATE,          -- 배송 시작일(기본값)
        DELIVERY_END_DATE             -- 배송 종료일(시작일 + 3일)
    ) VALUES (
                 NVL((SELECT MAX(PLATFORM_DELIVERY_RETURN_ID) FROM PLATFORM_DELIVERY_RETURN), 0) + 1,
                 :NEW.PLATFORM_DELIVERY_ID,
                 :NEW.DELIVERY_START_DATE,     -- 원본 배송의 배송 시작일을 사용
                 :NEW.DELIVERY_START_DATE + 3  -- 배송 시작일로부터 3일 후로 설정
             );
EXCEPTION
    WHEN OTHERS THEN
        -- 오류 발생 시 로깅하거나 다른 처리
        DBMS_OUTPUT.PUT_LINE('Error in TR_INSERT_PLATFORM_DELIVERY_RETURN: ' || SQLERRM);
END;
/

