create view POST_REPORT_SUM2 as
SELECT PRS.회원코드, 관리자_ID, 게시글_신고접수_ID, 게시글_신고접수자_ID, 게시물_ID, 게시글_신고유형_ID, 게시글_신고_내용_ID, 게시글_신고일
     ,PRA.POST_REPORT_ACTION_ID AS 신고_처리_ID,PRA.ADMIN_ID AS 처리_관리자_ID,PRA.POST_REPORT_ID AS 게시글_신고_접수_ID,PRA.REPORT_ACTION_TYPE_ID AS 신고_처리_유형_ID,PRA.COMPLETED_DATE AS 처리일
FROM POST_REPORT_SUM PRS JOIN POST_REPORT_ACTION PRA
                              ON PRS.관리자_ID = PRA.ADMIN_ID
/

