create view P_RENTAL as
SELECT PR.회원_코드, PR.장비등록_장비코드, PR.렌탈_ID, PR.결제_금액, PR.결제_일자, PR.결제_ID
     ,RMR.RENTAL_MATCHING_REQ_ID AS 렌탈_매칭_신청_ID,RMR.RENTAL_START_DATE AS 매칭_렌탈_시작일,RMR.RENTAL_END_DATE AS 매칭_렌탈_종료일,RMR.REQUESTED_DATE AS 렌탈_매칭_신청일
FROM PAY_RENTAL PR JOIN RENTAL_MATCHING_REQ RMR
                        ON PR.렌탈_ID = RMR.RENTAL_ID
/

