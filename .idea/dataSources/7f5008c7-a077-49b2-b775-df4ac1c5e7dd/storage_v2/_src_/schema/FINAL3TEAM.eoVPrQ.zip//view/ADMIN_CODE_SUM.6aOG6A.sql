create view ADMIN_CODE_SUM as
SELECT U.회원코드, A.ADMIN_ID AS 관리자_ID
FROM USER_CODE_SUM U JOIN ADMINS A
                          ON U.회원코드 = A.USER_CODE
/

