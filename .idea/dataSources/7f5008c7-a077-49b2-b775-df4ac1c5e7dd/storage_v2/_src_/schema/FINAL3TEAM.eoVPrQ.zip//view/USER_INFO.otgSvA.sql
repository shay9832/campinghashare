create view USER_INFO as
SELECT UC.USER_CODE AS 회원코드,U.USER_ID AS 회원_ID,U.USER_NAME AS 회원_이름
     ,U.USER_TEL AS 회원_전화번호,U.USER_EMAIL AS 회원_이메일,U.CREATED_DATE AS 회원가입일
     ,P.POST_ID AS 게시물_ID,P.USER_CODE AS 게시물_회원_코드,P.BOARD_ID AS 게시판_ID,P.POST_LABEL_ID AS 말머리_ID,P.POST_TITLE AS 게시물_제목,P.POST_CONTENT AS 게시물_내용,P.CREATED_DATE AS 게시물_생성일
     ,R.REPLY_ID AS 댓글_ID,R.ROOT_REPLY_ID AS 상윗댓글_ID,R.USER_CODE AS 댓글_회원_코드,R.POST_ID AS 댓글_게시물_ID,REPLY_CONTENT AS 댓글_내용,R.CREATED_DATE AS 댓글_생성일
     ,PL.POINT_LOG_ID AS 포인트_로그_ID,PL.USER_CODE AS 포인트_변동_회원_코드,PL.POINT_CHANGE_TYPE_ID AS 포인트_변동_유형_ID,PL.POINT_CHANGE AS 변동_포인트,PL.CREATED_DATE AS 포인트_변동_생성일
     ,SL.SATIS_LOG_ID AS 만족도_평가_로그_ID,SL.RENTAL_MATCHING_DONE_ID AS 만족도_평가_렌탈_완료,SL.REVIEWEE_ID AS 피평가자_ID,SL.REVIEWER_ID AS 평가자_ID
     ,SL.SATIS_SCORE AS 만족도_점수,SL.SATIS_COMMENT AS 만족도_코멘트,SL.CREATED_DATE AS 만족도_평가_생성일
FROM USER_CODE UC JOIN USERS U
                       ON UC.USER_CODE = U.USER_CODE
                  JOIN POST P
                       ON U.USER_CODE = P.USER_CODE
                  JOIN REPLY R
                       ON P.USER_CODE = R.USER_CODE
                  JOIN POINT_LOG PL
                       ON R.USER_CODE = PL.USER_CODE
                  JOIN SATISFACTION_LOG SL
                       ON PL.USER_CODE = SL.REVIEWEE_ID
/

