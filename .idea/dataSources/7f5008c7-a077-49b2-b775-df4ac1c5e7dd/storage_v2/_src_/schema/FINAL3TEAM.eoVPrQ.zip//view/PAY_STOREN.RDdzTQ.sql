create view PAY_STOREN as
SELECT US.회원_코드,US.장비등록_장비코드,US.스토렌_ID,PAY_AMOUNT AS 결제_금액, PAY_DATE AS 결제_일자, PAY_ID AS 결제_ID
FROM USER_STOREN US JOIN PAY P
                         ON US.스토렌_ID = P.STOREN_ID
/

