create view V_TODAY_USER_RESTORE as
SELECT TUS.회원_코드, TUS.스토렌_ID, 스토렌_매칭_완료_ID, 스토렌_결제_금액, 보관_결제_금액, 보관_결제_일자, 렌탈_결제_금액, 렌탈_결제_일자, 회원가입일
     ,IST.검수_결과_ID, IST.검수_결과_처리일
FROM IRA_STOREN IST JOIN TODAY_USER_SUM TUS
                         ON IST.회원_코드 = TUS.회원_코드
/

