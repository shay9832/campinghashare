create PROCEDURE PRC_INSERT_PAY_AND_USE_COUPON(
    p_methodName IN VARCHAR2,
    p_requestId IN STOREN_MATCHING_REQ.STOREN_MATCHING_REQ_ID%TYPE,
    p_amount IN PAY.PAY_AMOUNT%TYPE,
    p_couponId IN OWNED_COUPON.OWNED_COUPON_ID%TYPE,
    p_payType IN VARCHAR2,            -- 'storen-rent', 'rental-rent', 'storen-storage', 'storage-storage'
    p_result OUT NUMBER
)
AS
    v_methodId PAY_METHOD.PAY_METHOD_ID%TYPE;
    v_matchingDoneId NUMBER;
    v_payId NUMBER;
    USER_DEFINE_ERROR EXCEPTION;
BEGIN
    -- 1. 결제방법 ID 찾아서 v_methodId 변수에 넣기
    IF (p_methodName LIKE '%card%') THEN
        SELECT PAY_METHOD_ID INTO v_methodId
        FROM PAY_METHOD
        WHERE PAY_METHOD_NAME LIKE '%카드%';

    ELSIF (p_methodName LIKE '%bank%') THEN
        SELECT PAY_METHOD_ID INTO v_methodId
        FROM PAY_METHOD
        WHERE PAY_METHOD_NAME LIKE '%계좌%';

    ELSE
        RAISE USER_DEFINE_ERROR;
    END IF;

    -- 2. PAY 시퀀스에서 다음 PAY_ID 받아서 v_payId 변수에 넣기
    SELECT PAY_SEQ.NEXTVAL INTO v_payId FROM DUAL;

    -- 3. p_payType 조건에 따라 PAY 테이블에 INSERT
    IF (p_payType = 'storen-rent') THEN
        INSERT INTO PAY(PAY_ID, PAY_METHOD_ID, STOREN_MATCHING_DONE_ID, PAY_AMOUNT, PAY_DATE)
        SELECT v_payId, v_methodId, SMD.STOREN_MATCHING_DONE_ID, p_amount, SYSDATE
        FROM STOREN_MATCHING_REQ SMR
        JOIN STOREN_MATCHING_DONE SMD ON SMR.STOREN_MATCHING_REQ_ID = SMD.STOREN_MATCHING_REQ_ID
        WHERE SMR.STOREN_MATCHING_REQ_ID = p_requestId;

    ELSIF (p_payType = 'rental-rent') THEN
        INSERT INTO PAY(PAY_ID, PAY_METHOD_ID, RENTAL_MATCHING_DONE_ID, PAY_AMOUNT, PAY_DATE)
        SELECT v_payId, v_methodId, RMD.RENTAL_MATCHING_DONE_ID, p_amount, SYSDATE
        FROM RENTAL_MATCHING_REQ RMR
        JOIN RENTAL_MATCHING_DONE RMD ON RMR.RENTAL_MATCHING_REQ_ID = RMD.RENTAL_MATCHING_REQ_ID;

    ELSIF (p_payType = 'storen-storage') THEN
        INSERT INTO PAY(PAY_ID, PAY_METHOD_ID, STOREN_ID, PAY_AMOUNT, PAY_DATE)
        VALUES (v_payId, v_methodId, p_requestId, p_amount, SYSDATE);

    ELSIF (p_payType = 'storage-storage') THEN
        INSERT INTO PAY(PAY_ID, PAY_METHOD_ID, STORAGE_ID, PAY_AMOUNT, PAY_DATE)
        VALUES (v_payId, v_methodId, p_requestId, p_amount, SYSDATE);

    ELSE
        RAISE USER_DEFINE_ERROR;
    END IF;

    -- 4. 쿠폰 사용 처리
    IF (p_couponId IS NOT NULL)
    THEN UPDATE OWNED_COUPON
         SET COMPLETED_DATE = SYSDATE
         WHERE OWNED_COUPON_ID = p_couponId;
    END IF;

    -- 5. 로그 기록
    DBMS_OUTPUT.PUT_LINE('결제 완료. PAY_ID : ' || v_payId);

    -- 6. 반환할 결과값 p_result에 값 넣기
    p_result := v_payId; -- 성공

    -- 7. 커밋
    COMMIT;

EXCEPTION
    WHEN USER_DEFINE_ERROR THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('대상을 찾을 수 없습니다. 오류: ' || SQLERRM);
        p_result := -1;
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('오류 발생: ' || SQLERRM);
        p_result := -1;
END PRC_INSERT_PAY_AND_USE_COUPON;
/

