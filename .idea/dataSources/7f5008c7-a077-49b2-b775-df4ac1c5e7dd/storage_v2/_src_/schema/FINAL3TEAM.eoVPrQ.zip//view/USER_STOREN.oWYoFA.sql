create view USER_STOREN as
SELECT TP.회원_코드, TP.장비등록_장비코드, ST.STOREN_ID AS 스토렌_ID
FROM T_PRICE TP JOIN STOREN ST
                     ON TP.장비등록_장비코드 = ST.EQUIP_CODE
/

