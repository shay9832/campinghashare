create view ALL_USER as
SELECT 회원아이디,회원코드,회원이름,회원전화번호,회원닉네임,회원이메일
       ,AL.ADDRESS_ID AS 주소아이디,AL.ZIPCODE AS 우편번호, AL.ADDRESS AS 주소
FROM ALL_USERS AU JOIN ADDRESS_LOG AL
ON AU.회원코드 = AL.USER_CODE
/

