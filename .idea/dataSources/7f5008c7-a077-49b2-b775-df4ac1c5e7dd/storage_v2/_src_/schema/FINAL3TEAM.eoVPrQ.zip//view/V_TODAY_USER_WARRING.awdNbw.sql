create view V_TODAY_USER_WARRING as
SELECT VT.회원_코드, 스토렌_ID, 스토렌_매칭_완료_ID, 스토렌_결제_금액, 보관_결제_금액, 보관_결제_일자, 렌탈_결제_금액, 렌탈_결제_일자, 회원가입일, 검수_결과_ID, 검수_결과_처리일
        ,VTW.게시글_신고접수_ID, VTW.게시글_신고일,VTW.댓글_신고_접수_ID,VTW.댓글_신고일,VTW.렌탈_댓글_신고_접수_ID,VTW.렌탈_댓글_신고일
FROM V_TODAY_USER_RESTORE VT JOIN V_TODAY_WARRING VTW
ON VT.회원_코드 = VTW.회원코드
/

