create view T_PRICE as
SELECT UC.회원_코드, ER.EQUIP_CODE AS 장비등록_장비코드
FROM USER_COUNT UC JOIN EQUIPMENT_REGISTRATION ER
                        ON UC.회원_코드 = ER.USER_CODE
/

