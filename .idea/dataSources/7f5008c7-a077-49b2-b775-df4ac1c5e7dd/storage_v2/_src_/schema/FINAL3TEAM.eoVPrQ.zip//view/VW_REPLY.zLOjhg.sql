create view VW_REPLY as
SELECT REP.REPLY_ID AS "댓글ID"
     , REP.ROOT_REPLY_ID AS "상위댓글ID"
     , UC.USER_CODE AS "회원코드"
     , NL.NICKNAME AS "회원닉네임"
     , REP.POST_ID AS "게시물ID"
     , REP.REPLY_CONTENT AS "댓글내용"
     , REP.CREATED_DATE AS "작성일"
     , CASE WHEN REP.ROOT_REPLY_ID IS NULL
                THEN 0 ELSE 1
    END AS "대댓글여부"
FROM REPLY REP
         JOIN USER_CODE UC
              ON REP.USER_CODE = UC.USER_CODE
         JOIN NICKNAME_LOG NL
              ON UC.USER_CODE = NL.USER_CODE
                  AND NL.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                            FROM NICKNAME_LOG
                                            WHERE USER_CODE = UC.USER_CODE)
ORDER BY CASE WHEN REP.ROOT_REPLY_ID IS NULL
                  THEN REP.REPLY_ID ELSE REP.ROOT_REPLY_ID
             END ASC, REP.CREATED_DATE ASC
/

