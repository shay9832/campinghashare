create view V_TODAY_WARRING as
SELECT PRS.회원코드,PRS.게시글_신고접수_ID, PRS.게시글_신고일,RRS.댓글_신고_접수_ID,RRS.신고일 AS 댓글_신고일,RRSS.렌탈_댓글_신고_접수_ID,RRSS.렌탈_댓글_신고일
FROM POST_REPORT_SUM PRS JOIN REPLY_REPORT_SUM RRS
                              ON PRS.회원코드 = RRS.회원코드
                         JOIN RENTAL_REPLY_SUM RRSS
                              ON RRSS.회원코드 = RRS.회원코드
/

