create PROCEDURE PROC_CREATE_RETURN_DELIVERY AS
BEGIN
    -- 오늘이 렌탈 종료일인 렌탈 매칭 처리 대신 모든 종료 예정 렌탈 처리
    FOR rental_match IN (
        SELECT
            pd.PLATFORM_DELIVERY_ID,
            rmd.RENTAL_MATCHING_DONE_ID,
            rmr.RENTAL_END_DATE
        FROM RENTAL_MATCHING_REQ rmr
                 JOIN RENTAL_MATCHING_DONE rmd ON rmr.RENTAL_MATCHING_REQ_ID = rmd.RENTAL_MATCHING_REQ_ID
                 JOIN PAY p ON rmd.RENTAL_MATCHING_DONE_ID = p.RENTAL_MATCHING_DONE_ID
                 JOIN PLATFORM_DELIVERY pd ON p.PAY_ID = pd.PAY_ID
        WHERE 1=1  -- 날짜 조건 제거 (모든 렌탈 매칭 선택)
          AND NOT EXISTS (
            SELECT 1
            FROM PLATFORM_DELIVERY_RETURN pdr
            WHERE pdr.PLATFORM_DELIVERY_ID = pd.PLATFORM_DELIVERY_ID
        )
        ) LOOP
            -- 반환 배송 생성
            INSERT INTO PLATFORM_DELIVERY_RETURN (
                PLATFORM_DELIVERY_RETURN_ID,
                DELIVERY_START_DATE,
                DELIVERY_END_DATE,
                PLATFORM_DELIVERY_ID
            ) VALUES (
                         NVL((SELECT MAX(PLATFORM_DELIVERY_RETURN_ID) FROM PLATFORM_DELIVERY_RETURN), 0) + 1,
                         TRUNC(SYSDATE), -- 오늘 날짜
                         TRUNC(SYSDATE) + 3, -- 3일 후
                         rental_match.PLATFORM_DELIVERY_ID
                     );
        END LOOP;

    -- 스토렌 매칭도 같은 방식으로 수정
    FOR storen_match IN (
        SELECT
            pd.PLATFORM_DELIVERY_ID,
            smd.STOREN_MATCHING_DONE_ID,
            smr.RENTAL_END_DATE
        FROM STOREN_MATCHING_REQ smr
                 JOIN STOREN_MATCHING_DONE smd ON smr.STOREN_MATCHING_REQ_ID = smd.STOREN_MATCHING_REQ_ID
                 JOIN PAY p ON smd.STOREN_MATCHING_DONE_ID = p.STOREN_MATCHING_DONE_ID
                 JOIN PLATFORM_DELIVERY pd ON p.PAY_ID = pd.PAY_ID
        WHERE 1=1  -- 날짜 조건 제거
          AND NOT EXISTS (
            SELECT 1
            FROM PLATFORM_DELIVERY_RETURN pdr
            WHERE pdr.PLATFORM_DELIVERY_ID = pd.PLATFORM_DELIVERY_ID
        )
        ) LOOP
            -- 반환 배송 생성
            INSERT INTO PLATFORM_DELIVERY_RETURN (
                PLATFORM_DELIVERY_RETURN_ID,
                DELIVERY_START_DATE,
                DELIVERY_END_DATE,
                PLATFORM_DELIVERY_ID
            ) VALUES (
                         NVL((SELECT MAX(PLATFORM_DELIVERY_RETURN_ID) FROM PLATFORM_DELIVERY_RETURN), 0) + 1,
                         TRUNC(SYSDATE),
                         TRUNC(SYSDATE) + 3,
                         storen_match.PLATFORM_DELIVERY_ID
                     );
        END LOOP;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('ERROR: ' || SQLERRM);
END PROC_CREATE_RETURN_DELIVERY;
/

