create view STOREN_PAY as
SELECT SS.회원_코드, 장비등록_장비코드, 스토렌_ID, 결제_금액, 결제_일자, 결제_ID, 플랫폼_배송_ID, 배송_시작일, 배송_종료일, 플랫폼_배송_반환_ID, PS_배송_시작일, PS_배송_종료일, 검수리스트_ID, 검수_결과_ID, 검수_결과_처리_ID, 스토렌_매칭_신청_ID, 렌탈_시작일, 렌탈_종료일, 신청일
        , STOREN_MATCHING_DONE_ID AS 스토렌_매칭_완료_ID,APPROVED_DATE AS 승인_일자
FROM SMR_STOREN SS JOIN STOREN_MATCHING_DONE SMD
ON SS.스토렌_매칭_신청_ID = SMD.STOREN_MATCHING_REQ_ID
/

