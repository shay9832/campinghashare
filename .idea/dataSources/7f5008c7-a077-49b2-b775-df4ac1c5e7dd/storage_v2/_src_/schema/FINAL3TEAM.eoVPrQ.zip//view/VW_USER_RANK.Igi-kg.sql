create view VW_USER_RANK as
WITH 사용자_포인트 AS (
    SELECT USER_CODE, NVL(SUM(POINT_CHANGE), 0) AS 총포인트
    FROM POINT_LOG
    GROUP BY USER_CODE
),
     사용자_신용점수 AS (
         SELECT REVIEWEE_ID AS USER_CODE, NVL(AVG(SATIS_SCORE), 0) AS 신용점수
         FROM SATISFACTION_LOG
         GROUP BY REVIEWEE_ID
     ),
     닉네임_변경횟수 AS (
         SELECT USER_CODE, COUNT(*) - 1 AS 닉네임변경횟수
         FROM NICKNAME_LOG
         GROUP BY USER_CODE
     ),
     보유쿠폰_수 AS (
         SELECT USER_CODE, COUNT(*) AS 사용가능쿠폰수
         FROM OWNED_COUPON
         WHERE COMPLETED_DATE IS NULL
         GROUP BY USER_CODE
     ),
     현재_닉네임 AS (
         SELECT USER_CODE, NICKNAME
         FROM (
                  SELECT USER_CODE, NICKNAME,
                         ROW_NUMBER() OVER (PARTITION BY USER_CODE ORDER BY LAST_UPDATED_DATE DESC) AS RN
                  FROM NICKNAME_LOG
              )
         WHERE RN = 1
     )
SELECT
    U.USER_CODE,
    U.USER_ID,
    U.USER_NAME,
    CN.NICKNAME AS 현재닉네임,
    R.RANK_ID,
    R.RANK_NAME,
    R.RANK_ATTACHMENT_PATH,
    NVL(UP.총포인트, 0) AS 총포인트,
    NVL(UC.신용점수, 0) AS 신용점수,
    NVL(NC.닉네임변경횟수, 0) AS 닉네임변경횟수,
    U.CREATED_DATE AS 가입일,
    NVL(CC.사용가능쿠폰수, 0) AS 사용가능쿠폰수,
    CASE
        WHEN EXISTS (SELECT 1 FROM SUSPENDED_USER SU WHERE SU.USER_CODE = U.USER_CODE) THEN '활동정지'
        WHEN UCD.EXIT_DATE IS NOT NULL THEN '탈퇴회원'
        ELSE '정상회원'
        END AS 회원상태
FROM
    USERS U
        JOIN USER_CODE UCD ON U.USER_CODE = UCD.USER_CODE
        LEFT JOIN 현재_닉네임 CN ON U.USER_CODE = CN.USER_CODE
        LEFT JOIN 사용자_포인트 UP ON U.USER_CODE = UP.USER_CODE
        LEFT JOIN 사용자_신용점수 UC ON U.USER_CODE = UC.USER_CODE
        LEFT JOIN 닉네임_변경횟수 NC ON U.USER_CODE = NC.USER_CODE
        LEFT JOIN 보유쿠폰_수 CC ON U.USER_CODE = CC.USER_CODE
        LEFT JOIN RANK R ON (
        NVL(UP.총포인트, 0) BETWEEN R.MIN_POINT AND R.MAX_POINT
            AND NVL(UC.신용점수, 0) BETWEEN R.MIN_CREDIT AND R.MAX_CREDIT
        )
WHERE
    UCD.EXIT_DATE IS NULL
ORDER BY
    NVL(UP.총포인트, 0) DESC,
    NVL(UC.신용점수, 0) DESC,
    U.CREATED_DATE ASC
/

