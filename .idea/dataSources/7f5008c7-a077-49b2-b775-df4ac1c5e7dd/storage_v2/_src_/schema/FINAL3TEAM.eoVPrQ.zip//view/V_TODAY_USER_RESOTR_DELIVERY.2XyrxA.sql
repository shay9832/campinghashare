create view V_TODAY_USER_RESOTR_DELIVERY as
SELECT VT.회원_코드, VT.스토렌_ID, 스토렌_매칭_완료_ID, 스토렌_결제_금액, 보관_결제_금액, 보관_결제_일자, 렌탈_결제_금액, 렌탈_결제_일자, 회원가입일, 검수_결과_ID,검수_결과_처리일
     ,PS.배송_시작일,PS.배송_종료일
FROM V_TODAY_USER_RESTORE VT JOIN PDR_STOREN PS
                                  ON VT.회원_코드 = PS.회원_코드
/

