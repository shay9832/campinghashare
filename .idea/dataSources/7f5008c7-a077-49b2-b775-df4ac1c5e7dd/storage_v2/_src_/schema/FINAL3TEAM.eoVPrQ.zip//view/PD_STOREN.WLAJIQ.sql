create view PD_STOREN as
SELECT PS.회원_코드, 장비등록_장비코드, 스토렌_ID, 결제_금액, 결제_일자, 결제_ID, PLATFORM_DELIVERY_ID AS 플랫폼_배송_ID
     ,DELIVERY_START_DATE AS 배송_시작일, DELIVERY_END_DATE AS 배송_종료일
FROM PAY_STOREN PS JOIN PLATFORM_DELIVERY PD
                        ON PS.결제_ID = PD.PAY_ID
/

