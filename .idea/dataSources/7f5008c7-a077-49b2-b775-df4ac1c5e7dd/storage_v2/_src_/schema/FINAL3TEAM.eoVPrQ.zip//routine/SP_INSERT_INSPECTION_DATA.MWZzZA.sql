create PROCEDURE SP_INSERT_INSPECTION_DATA
(
    -- 장비 기본 정보
    p_equip_code                    IN VARCHAR2,
    p_delivery_id                   IN VARCHAR2,
    p_inspection_type               IN VARCHAR2,
    p_admin_id                      IN VARCHAR2,

    -- 체크리스트 항목 점수 정보 (배열로 처리)
    p_item_names                    IN SYS.ODCIVARCHAR2LIST,
    p_item_grades                   IN SYS.ODCIVARCHAR2LIST,
    p_item_comments                 IN SYS.ODCIVARCHAR2LIST,
    p_item_scores                   IN SYS.ODCINUMBERLIST,

    -- 결과 정보
    p_total_score                   IN NUMBER,
    p_final_grade                   IN CHAR,

    -- 출력 파라미터
    p_result                        OUT NUMBER,
    p_message                       OUT VARCHAR2
)
    IS
    v_inspec_list_id                NUMBER;
    v_inspec_grade_id               NUMBER;
    v_inspec_result_id              NUMBER;
    v_equip_grade_id                NUMBER;
    v_platform_delivery_id          NUMBER := NULL;
    v_platform_delivery_return_id   NUMBER := NULL;
    v_category_id                   NUMBER;
    v_cate_inspec_id                NUMBER;
    v_inspec_item_id                NUMBER;
BEGIN
    -- 결과 초기화
    p_result := 1;
    p_message := '검수 처리가 완료되었습니다.';

    -- 트랜잭션 시작
    SAVEPOINT sp_start;

    -- 1. 우선 배송 ID 찾기 (입고검수 or 반환검수 확인)
    IF p_inspection_type = '입고검수' OR p_inspection_type = '최종검수' THEN
        BEGIN
            SELECT PLATFORM_DELIVERY_ID INTO v_platform_delivery_id
            FROM PLATFORM_DELIVERY
            WHERE PLATFORM_DELIVERY_ID = TO_NUMBER(SUBSTR(p_delivery_id, 6));
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_result := 0;
                p_message := '해당 배송 ID를 찾을 수 없습니다.';
                ROLLBACK TO sp_start;
                RETURN;
        END;
    ELSIF p_inspection_type = '스토렌반환검수' THEN
        BEGIN
            SELECT PLATFORM_DELIVERY_RETURN_ID INTO v_platform_delivery_return_id
            FROM PLATFORM_DELIVERY_RETURN
            WHERE PLATFORM_DELIVERY_RETURN_ID = TO_NUMBER(SUBSTR(p_delivery_id, 6));
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                p_result := 0;
                p_message := '해당 반환 배송 ID를 찾을 수 없습니다.';
                ROLLBACK TO sp_start;
                RETURN;
        END;
    END IF;

    -- 2. 장비 카테고리 찾기
    BEGIN
        SELECT er.CATEGORY_ID INTO v_category_id
        FROM EQUIPMENT_REGISTRATION er
        WHERE er.EQUIP_CODE = TO_NUMBER(p_equip_code);
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_result := 0;
            p_message := '해당 장비 코드를 찾을 수 없습니다.';
            ROLLBACK TO sp_start;
            RETURN;
    END;

    -- 3. 등급 ID 찾기
    BEGIN
        SELECT INSPEC_GRADE_ID INTO v_inspec_grade_id
        FROM INSPEC_GRADE
        WHERE INSPEC_GRADE_NAME = p_final_grade;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_result := 0;
            p_message := '해당 등급 정보를 찾을 수 없습니다.';
            ROLLBACK TO sp_start;
            RETURN;
    END;

    -- 4. 장비 등급 ID 찾기
    BEGIN
        SELECT EQUIP_GRADE_ID INTO v_equip_grade_id
        FROM EQUIP_GRADE
        WHERE EQUIP_GRADE_NAME = p_final_grade;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_result := 0;
            p_message := '해당 장비 등급 정보를 찾을 수 없습니다.';
            ROLLBACK TO sp_start;
            RETURN;
    END;

    -- 5. 검수 리스트 ID 생성
    SELECT NVL(MAX(INSPEC_LIST_ID), 0) + 1 INTO v_inspec_list_id
    FROM INSPEC_LIST;

    -- 6. 검수 결과 ID 생성
    SELECT NVL(MAX(INSPEC_RESULT_ID), 0) + 1 INTO v_inspec_result_id
    FROM INSPEC_RESULT;

    -- 7. 검수 리스트 추가
    INSERT INTO INSPEC_LIST (
        INSPEC_LIST_ID,
        INSPEC_COMMENT,
        PLATFORM_DELIVERY_ID,
        PLATFORM_DELIVERY_RETURN_ID,
        ADMIN_ID,
        INSPEC_GRADE_ID,
        INSPECTION_DATE
    ) VALUES (
                 v_inspec_list_id,
                 p_final_grade || '등급으로 검수 완료',
                 v_platform_delivery_id,
                 v_platform_delivery_return_id,
                 p_admin_id,
                 v_inspec_grade_id,
                 SYSDATE
             );

    -- 8. 검수 결과 추가
    INSERT INTO INSPEC_RESULT (
        INSPEC_RESULT_ID,
        PLATFORM_DELIVERY_ID,
        PLATFORM_DELIVERY_RETURN_ID,
        EQUIP_GRADE_ID
    ) VALUES (
                 v_inspec_result_id,
                 v_platform_delivery_id,
                 v_platform_delivery_return_id,
                 v_equip_grade_id
             );

    -- 9. 검수 항목별 처리
    FOR i IN 1..p_item_names.COUNT LOOP
            -- 항목 ID 찾기
            BEGIN
                SELECT ii.INSPEC_ITEM_ID INTO v_inspec_item_id
                FROM INSPEC_ITEM ii
                WHERE ii.INSPEC_ITEM_NAME = p_item_names(i);
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    CONTINUE; -- 찾지 못하면 다음 항목으로
            END;

            -- 카테고리별 검수항목 ID 찾기
            BEGIN
                SELECT ci.CATE_INSPEC_ID INTO v_cate_inspec_id
                FROM CATE_INSPEC ci
                WHERE ci.CATEGORY_ID = v_category_id
                  AND ci.INSPEC_ITEM_ID = v_inspec_item_id;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    -- 카테고리별 검수항목이 없으면 새로 생성
                    SELECT NVL(MAX(CATE_INSPEC_ID), 0) + 1 INTO v_cate_inspec_id
                    FROM CATE_INSPEC;

                    INSERT INTO CATE_INSPEC (
                        CATE_INSPEC_ID,
                        CATEGORY_ID,
                        INSPEC_ITEM_ID
                    ) VALUES (
                                 v_cate_inspec_id,
                                 v_category_id,
                                 v_inspec_item_id
                             );
            END;

            -- 검수 리스트 업데이트 (카테고리별 검수항목 지정)
            UPDATE INSPEC_LIST
            SET CATE_INSPEC_ID = v_cate_inspec_id
            WHERE INSPEC_LIST_ID = v_inspec_list_id;

            -- 여기에 각 검수 항목별 결과를 별도 테이블에 저장하는 로직을 추가할 수 있음
            -- (현재 제공된 테이블 구조에는 항목별 결과를 저장하는 테이블이 명확하지 않음)
        END LOOP;

    -- 검수 결과에 따른 처리 로직 추가 가능
    -- (예: 결과에 따라 장비 상태 변경 등)

    -- 트랜잭션 커밋
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        -- 오류 발생 시 롤백
        ROLLBACK;
        p_result := 0;
        p_message := '오류 발생: ' || SQLERRM;
END SP_INSERT_INSPECTION_DATA;
/

