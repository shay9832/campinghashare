create view VW_REPORT_MANAGEMENT as
SELECT PR.POST_REPORT_ID AS "신고접수ID"
     , NL_REPORTER.NICKNAME AS "신고자닉네임"
     , NL_REPORTED.NICKNAME AS "피신고자닉네임"
     , POS.POST_ID AS "분류"
     , RT.REPORT_TYPE_NAME AS "신고유형"
     , PR.REPORT_CONTENT AS "신고내용"
     , PR.REPORTED_DATE AS "신고일"
     , PRA.ADMIN_ID AS "관리자ID"
     , CASE WHEN PRA.POST_REPORT_ACTION_ID IS NOT NULL
                THEN '처리완료'
            ELSE '접수'
    END AS "처리상태"
     , PRA.COMPLETED_DATE AS "처리일"
FROM POST_REPORT PR
         JOIN USER_CODE UC_REPORTER
              ON PR.REPORTER_ID = UC_REPORTER.USER_CODE
         JOIN NICKNAME_LOG NL_REPORTER
              ON UC_REPORTER.USER_CODE = NL_REPORTER.USER_CODE
                  AND NL_REPORTER.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                                     FROM NICKNAME_LOG
                                                     WHERE USER_CODE = UC_REPORTER.USER_CODE)
         JOIN POST POS
              ON PR.POST_ID = POS.POST_ID
         JOIN USER_CODE UC_REPORTED
              ON POS.USER_CODE = UC_REPORTED.USER_CODE
         JOIN NICKNAME_LOG NL_REPORTED
              ON UC_REPORTED.USER_CODE = NL_REPORTED.USER_CODE
                  AND NL_REPORTED.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                                     FROM NICKNAME_LOG
                                                     WHERE USER_CODE = UC_REPORTED.USER_CODE)
         JOIN REPORT_TYPE RT
              ON PR.REPORT_TYPE_ID = RT.REPORT_TYPE_ID
         JOIN POST_REPORT_ACTION PRA
              ON PR.POST_REPORT_ID = PRA.POST_REPORT_ID

UNION ALL

SELECT RR.REPLY_REPORT_ID AS "신고접수ID"
     , NL_REPORTER.NICKNAME AS "신고자닉네임"
     , NL_REPORTED.NICKNAME AS "피신고자닉네임"
     , RR.REPLY_ID AS "분류"
     , RT.REPORT_TYPE_NAME AS "신고유형"
     , RR.REPORT_CONTENT AS "신고내용"
     , RR.REPORTED_DATE AS "신고일"
     , RRA.ADMIN_ID AS "관리자ID"
     , CASE WHEN RRA.REPLY_REPORT_ACTION_ID IS NOT NULL
                THEN '처리완료'
            ELSE '접수'
    END AS "처리상태"
     , RRA.COMPLETED_DATE AS "처리일"
FROM REPLY_REPORT RR
         JOIN USER_CODE UC_REPORTER
              ON RR.REPORTER_ID = UC_REPORTER.USER_CODE
         JOIN NICKNAME_LOG NL_REPORTER
              ON UC_REPORTER.USER_CODE = NL_REPORTER.USER_CODE
                  AND NL_REPORTER.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                                     FROM NICKNAME_LOG
                                                     WHERE USER_CODE = UC_REPORTER.USER_CODE)
         JOIN REPLY REP
              ON RR.REPLY_ID = REP.REPLY_ID
         JOIN USER_CODE UC_REPORTED
              ON REP.USER_CODE = UC_REPORTED.USER_CODE
         JOIN NICKNAME_LOG NL_REPORTED
              ON UC_REPORTED.USER_CODE = NL_REPORTED.USER_CODE
                  AND NL_REPORTED.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                                     FROM NICKNAME_LOG
                                                     WHERE USER_CODE = UC_REPORTED.USER_CODE)
         JOIN REPORT_TYPE RT
              ON RR.REPORT_TYPE_ID = RT.REPORT_TYPE_ID
         JOIN REPLY_REPORT_ACTION RRA
              ON RR.REPLY_REPORT_ID = RRA.REPLY_REPORT_ID

UNION ALL

SELECT RRR.RENTAL_REPLY_REPORT_ID AS "신고접수ID"
     , NL_REPORTER.NICKNAME AS "신고자닉네임"
     , NL_REPORTED.NICKNAME AS "피신고자닉네임"
     , RRR.RENTAL_REPLY_ID AS "분류"
     , RT.REPORT_TYPE_NAME AS "신고유형"
     , RRR.REPORT_CONTENT AS "신고내용"
     , RRR.REPORTED_DATE AS "신고일"
     , RRRA.ADMIN_ID AS "관리자ID"
     , CASE WHEN RRRA.RENTAL_REPLY_REPORT_ACTION_ID IS NOT NULL
                THEN '처리완료'
            ELSE '접수'
    END AS "처리상태"
     , RRRA.COMPLETED_DATE AS "처리일"
FROM RENTAL_REPLY_REPORT RRR
         JOIN USER_CODE UC_REPORTER
              ON RRR.REPORTER_ID = UC_REPORTER.USER_CODE
         JOIN NICKNAME_LOG NL_REPORTER
              ON UC_REPORTER.USER_CODE = NL_REPORTER.USER_CODE
                  AND NL_REPORTER.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                                     FROM NICKNAME_LOG
                                                     WHERE USER_CODE = UC_REPORTER.USER_CODE)
         JOIN RENTAL_REPLY RR
              ON RRR.RENTAL_REPLY_ID = RR.RENTAL_REPLY_ID
         JOIN USER_CODE UC_REPORTED
              ON RR.USER_CODE = UC_REPORTED.USER_CODE
         JOIN NICKNAME_LOG NL_REPORTED
              ON UC_REPORTED.USER_CODE = NL_REPORTED.USER_CODE
                  AND NL_REPORTED.NICKNAME_LOG_ID = (SELECT MAX(NICKNAME_LOG_ID)
                                                     FROM NICKNAME_LOG
                                                     WHERE USER_CODE = UC_REPORTED.USER_CODE)
         JOIN REPORT_TYPE RT
              ON RRR.REPORT_TYPE_ID = RT.REPORT_TYPE_ID
         JOIN RENTAL_REPLY_REPORT_ACTION RRRA
              ON RRR.RENTAL_REPLY_REPORT_ID = RRRA.RENTAL_REPLY_REPORT_ID
/

