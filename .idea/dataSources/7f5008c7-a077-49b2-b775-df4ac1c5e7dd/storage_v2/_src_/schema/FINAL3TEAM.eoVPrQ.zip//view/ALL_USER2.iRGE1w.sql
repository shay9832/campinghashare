create view ALL_USER2 as
SELECT 회원아이디,회원코드,회원이름,회원전화번호,회원닉네임,회원이메일,
       ER.EQUIP_ID AS 장비아이디, ER.EQUIP_CODE AS 장비코드, ER.CATEGORY_ID 카테고리아이디, ER.EQUIP_NAME_ID AS 장비이름아이디
       ,ORIGINAL_PRICE AS 신품가격, ER.CREATED_DATE 생성일
FROM ALL_USER AU JOIN EQUIPMENT_REGISTRATION ER
ON AU.회원코드 = ER.USER_CODE
/

