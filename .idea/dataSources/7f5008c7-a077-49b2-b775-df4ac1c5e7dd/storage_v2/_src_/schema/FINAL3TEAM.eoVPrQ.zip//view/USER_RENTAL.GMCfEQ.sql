create view USER_RENTAL as
SELECT TP.회원_코드, TP.장비등록_장비코드, RT.RENTAL_ID AS 렌탈_ID
FROM T_PRICE TP JOIN RENTAL RT
                     ON TP.장비등록_장비코드 = RT.EQUIP_CODE
/

