create trigger TRG_HOT_POST_POINT_INSERT
    after insert
    on HOT_POST_LOG
    for each row
DECLARE
    V_POST_USER_CODE NUMBER;
BEGIN
    -- 인기글 지정된 게시물의 작성자 조회
    SELECT USER_CODE INTO V_POST_USER_CODE
    FROM POST
    WHERE POST.POST_ID = :NEW.POST_ID;

    INSERT INTO POINT_LOG (POINT_LOG_ID, USER_CODE, POINT_CHANGE_TYPE_ID, POINT_CHANGE, CREATED_DATE)
    VALUES (POINT_LOG_SEQ.nextval, V_POST_USER_CODE, (SELECT POINT_CHANGE_TYPE_ID
                                                                              FROM POINT_CHANGE_TYPE
                                                                              WHERE POINT_CHANGE_TYPE_NAME = '인기글 지정'), 5, SYSDATE);
END;
/

