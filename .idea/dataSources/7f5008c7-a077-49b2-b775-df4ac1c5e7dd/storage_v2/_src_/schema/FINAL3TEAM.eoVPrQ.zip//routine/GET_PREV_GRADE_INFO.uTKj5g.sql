create FUNCTION GET_PREV_GRADE_INFO(
    p_equip_code IN NUMBER
) RETURN VARCHAR2
IS
    -- 반환될 정보: '등급ID,등급명' 형태
    v_return_info VARCHAR2(10);
    v_prev_grade_id NUMBER;
    v_prev_grade CHAR(1);

    -- 독립 트랜잭션으로 선언
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    -- 장비 코드에 대한 최근 검수 결과의 등급 정보 조회
    BEGIN
        SELECT IR.EQUIP_GRADE_ID, EG.EQUIP_GRADE_NAME 
        INTO v_prev_grade_id, v_prev_grade
        FROM INSPEC_RESULT IR
        JOIN INSPEC_RESULT_ACTION IRA ON IR.INSPEC_RESULT_ID = IRA.INSPEC_RESULT_ID
        JOIN STOREN_IRA SI ON IRA.INSPEC_RESULT_ACTION_ID = SI.INSPEC_RESULT_ACTION_ID
        JOIN STOREN S ON SI.STOREN_ID = S.STOREN_ID
        JOIN EQUIP_GRADE EG ON IR.EQUIP_GRADE_ID = EG.EQUIP_GRADE_ID
        WHERE S.EQUIP_CODE = p_equip_code
        AND ROWNUM = 1
        ORDER BY IRA.COMPLETED_DATE DESC;

        v_return_info := v_prev_grade_id || ',' || v_prev_grade;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            v_return_info := '1,A'; -- 기본값: A 등급
    END;

    -- 독립 트랜잭션 완료
    COMMIT;

    RETURN v_return_info;
END GET_PREV_GRADE_INFO;
/

