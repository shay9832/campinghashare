create view VW_DELIVERY_MANAGEMENT as
SELECT
      '스토렌_최초입고'                          AS "배송종류"
    , ER.USER_CODE                              AS "발송인"
    , -1                                        AS "수취인"
    , S.STOREN_ID                               AS "스토렌ID"
    , P.STORAGE_ID                              AS "보관ID"
    , P.RENTAL_MATCHING_DONE_ID                 AS "렌탈매칭완료ID"
    , NULL                                      AS "렌탈시작일"
    , NULL                                      AS "렌탈종료일"
    , NULL                                      AS "렌탈ID"
    , PD.PLATFORM_DELIVERY_ID                   AS "배송ID"
    , EN.EQUIP_NAME                             AS "장비명"
    , NULL                                      AS "운송사이름"
    , NULL                                      AS "운송장번호"
    , PD.DELIVERY_START_DATE                    AS "배송시작일"
    , PD.DELIVERY_END_DATE                      AS "배송종료일"
    , IRA.COMPLETED_DATE                        AS "검수결과처리일"        --1차 검수일
    , IRAT.INSPEC_RESULT_ACTION_TYPE_NAME       AS "검수결과처리유형"      --1차 검수결과
FROM PAY P
JOIN STOREN S 
     ON P.STOREN_ID = S.STOREN_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON S.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN PLATFORM_DELIVERY PD 
     ON P.PAY_ID = PD.PAY_ID
LEFT JOIN INSPEC_RESULT IR 
     ON IR.PLATFORM_DELIVERY_ID = PD.PLATFORM_DELIVERY_ID
LEFT JOIN INSPEC_RESULT_ACTION IRA 
     ON IRA.INSPEC_RESULT_ID = IR.INSPEC_RESULT_ID
LEFT JOIN INSPEC_RESULT_ACTION_TYPE IRAT 
     ON IRA.INSPEC_RESULT_ACTION_TYPE_ID = IRAT.INSPEC_RESULT_ACTION_TYPE_ID
WHERE P.STOREN_ID IS NOT NULL

UNION ALL

-- 2. 보관 플랫폼배송최초입고
SELECT
      '보관_최초입고'                            AS "배송종류"
    , ER.USER_CODE                              AS "발송인"
    , -1                                        AS "수취인"
    , P.STOREN_ID                               AS "스토렌ID"
    , S.STORAGE_ID                              AS "보관ID"
    , P.RENTAL_MATCHING_DONE_ID                 AS "렌탈매칭완료ID"
    , NULL                                      AS "렌탈시작일"
    , NULL                                      AS "렌탈종료일"
    , NULL                                      AS "렌탈ID"
    , PD.PLATFORM_DELIVERY_ID                   AS "배송ID"
    , EN.EQUIP_NAME                             AS "장비명"
    , NULL                                      AS "운송사이름"
    , NULL                                      AS "운송장번호"
    , PD.DELIVERY_START_DATE                    AS "배송시작일"
    , PD.DELIVERY_END_DATE                      AS "배송종료일"
    , IRA.COMPLETED_DATE                        AS "검수결과처리일"        --1차 검수일
    , IRAT.INSPEC_RESULT_ACTION_TYPE_NAME       AS "검수결과처리유형"      --1차 검수결과과
FROM PAY P
JOIN STORAGE S 
     ON P.STORAGE_ID = S.STORAGE_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON S.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN PLATFORM_DELIVERY PD 
     ON P.PAY_ID = PD.PAY_ID
LEFT JOIN INSPEC_RESULT IR 
     ON IR.PLATFORM_DELIVERY_ID = PD.PLATFORM_DELIVERY_ID
LEFT JOIN INSPEC_RESULT_ACTION IRA 
     ON IRA.INSPEC_RESULT_ID = IR.INSPEC_RESULT_ID
LEFT JOIN INSPEC_RESULT_ACTION_TYPE IRAT 
     ON IRA.INSPEC_RESULT_ACTION_TYPE_ID = IRAT.INSPEC_RESULT_ACTION_TYPE_ID
WHERE P.STORAGE_ID IS NOT NULL

UNION ALL

-- 3. 렌탈_사용자배송_발송
SELECT
      '렌탈_발송'                                AS "배송종류"
    , ER.USER_CODE                              AS "발송인"
    , RMR.RENTAL_MATCHING_REQUESTER_ID          AS "수취인"
    , P.STOREN_ID                               AS "스토렌ID"
    , P.STORAGE_ID                              AS "보관ID"
    , P.RENTAL_MATCHING_DONE_ID                 AS "렌탈매칭완료ID"
    , RMR.RENTAL_START_DATE                     AS "렌탈시작일"
    , RMR.RENTAL_END_DATE                       AS "렌탈종료일"
    , R.RENTAL_ID                               AS "렌탈ID"
    , UD.USERS_DELIVERY_ID                      AS "배송ID"
    , EN.EQUIP_NAME                             AS "장비명"
    , UD.CARRIER_NAME                           AS "운송사이름"
    , UD.WAYBILL_NUMBER                         AS "운송장번호"
    , UD.WAYBILL_ENTRY_DATE                     AS "배송시작일"
    , UD.DELIVERY_END_DATE                      AS "배송종료일"
    , NULL                                      AS "검수결과처리일"
    , NULL                                      AS "검수결과처리유형"
FROM PAY P
JOIN RENTAL_MATCHING_DONE RMD
     ON P.RENTAL_MATCHING_DONE_ID = RMD.RENTAL_MATCHING_DONE_ID
JOIN RENTAL_MATCHING_REQ RMR
     ON RMD.RENTAL_MATCHING_REQ_ID = RMR.RENTAL_MATCHING_REQ_ID
JOIN RENTAL R
     ON RMR.RENTAL_ID = R.RENTAL_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON R.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN USERS_DELIVERY UD
     ON P.PAY_ID = UD.PAY_ID
WHERE P.RENTAL_MATCHING_DONE_ID IS NOT NULL

UNION ALL

-- 4. 스토렌_플랫폼배송_발송
SELECT
      '스토렌_매칭발송'                          AS "배송종류"
    , -1                                        AS "발송인"
    , SMR.STOREN_MATCHING_REQ_USER_ID           AS "수취인"
    , S.STOREN_ID                               AS "스토렌ID"
    , P.STORAGE_ID                              AS "보관ID"
    , P.STOREN_MATCHING_DONE_ID                 AS "렌탈매칭완료ID"
    , SMR.RENTAL_START_DATE                     AS "렌탈시작일"
    , SMR.RENTAL_END_DATE                       AS "렌탈종료일"
    , P.RENTAL_MATCHING_DONE_ID                 AS "렌탈ID"
    , PD.PLATFORM_DELIVERY_ID                   AS "배송ID"
    , EN.EQUIP_NAME                             AS "장비명"
    , NULL                                      AS "운송사이름"
    , NULL                                      AS "운송장번호"
    , PD.DELIVERY_START_DATE                    AS "배송시작일"
    , PD.DELIVERY_END_DATE                      AS "배송종료일"
    , IRA.COMPLETED_DATE                        AS "검수결과처리일"        --1차 검수일
    , IRAT.INSPEC_RESULT_ACTION_TYPE_NAME       AS "검수결과처리유형"      --1차 검수결과과
FROM PAY P
JOIN STOREN_MATCHING_DONE SMD
     ON P.STOREN_MATCHING_DONE_ID = SMD.STOREN_MATCHING_DONE_ID
JOIN STOREN_MATCHING_REQ SMR
     ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
JOIN STOREN_IRA SI
     ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
JOIN STOREN S
     ON SI.STOREN_ID = S.STOREN_ID
JOIN INSPEC_RESULT_ACTION IRA
     ON SI.INSPEC_RESULT_ACTION_ID = IRA.INSPEC_RESULT_ACTION_ID
JOIN INSPEC_RESULT_ACTION_TYPE IRAT
     ON IRA.INSPEC_RESULT_ACTION_TYPE_ID = IRAT.INSPEC_RESULT_ACTION_TYPE_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON S.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN PLATFORM_DELIVERY PD 
     ON P.PAY_ID = PD.PAY_ID
WHERE P.STOREN_MATCHING_DONE_ID IS NOT NULL

UNION ALL
-- 5. 스토렌_플랫폼배송_반납
SELECT
      '스토렌_매칭반납'                          AS "배송종류"
    , SMR.STOREN_MATCHING_REQ_USER_ID           AS "발송인"
    , -1                                        AS "수취인"
    , S.STOREN_ID                               AS "스토렌ID"
    , P.STORAGE_ID                              AS "보관ID"
    , P.STOREN_MATCHING_DONE_ID                 AS "렌탈매칭완료ID"
    , SMR.RENTAL_START_DATE                     AS "렌탈시작일"
    , SMR.RENTAL_END_DATE                       AS "렌탈종료일"
    , P.RENTAL_MATCHING_DONE_ID                 AS "렌탈ID"
    , PDR.PLATFORM_DELIVERY_RETURN_ID           AS "배송ID"               --반납 배송ID
    , EN.EQUIP_NAME                             AS "장비명"
    , NULL                                      AS "운송사이름"
    , NULL                                      AS "운송장번호"
    , PDR.DELIVERY_START_DATE                    AS "배송시작일"
    , PDR.DELIVERY_END_DATE                      AS "배송종료일"
    , IRA.COMPLETED_DATE                        AS "검수결과처리일"        --2차 검수일
    , IRAT.INSPEC_RESULT_ACTION_TYPE_NAME       AS "검수결과처리유형"      --2차 검수결과
FROM PLATFORM_DELIVERY PD
JOIN PAY P
     ON PD.PAY_ID = P.PAY_ID
JOIN STOREN_MATCHING_DONE SMD
     ON P.STOREN_MATCHING_DONE_ID = SMD.STOREN_MATCHING_DONE_ID
JOIN STOREN_MATCHING_REQ SMR
     ON SMD.STOREN_MATCHING_REQ_ID = SMR.STOREN_MATCHING_REQ_ID
JOIN STOREN_IRA SI
     ON SMR.STOREN_IRA_ID = SI.STOREN_IRA_ID
JOIN STOREN S
     ON SI.STOREN_ID = S.STOREN_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON S.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN PLATFORM_DELIVERY_RETURN PDR
     ON PD.PLATFORM_DELIVERY_ID = PDR.PLATFORM_DELIVERY_ID
JOIN INSPEC_RESULT IR
     ON PDR.PLATFORM_DELIVERY_RETURN_ID = IR.PLATFORM_DELIVERY_RETURN_ID
JOIN INSPEC_RESULT_ACTION IRA
     ON IR.INSPEC_RESULT_ID = IRA.INSPEC_RESULT_ID
JOIN INSPEC_RESULT_ACTION_TYPE IRAT
     ON IRA.INSPEC_RESULT_ACTION_TYPE_ID = IRAT.INSPEC_RESULT_ACTION_TYPE_ID
WHERE P.STOREN_MATCHING_DONE_ID IS NOT NULL


UNION ALL
-- 6. 스토렌_최종반환
SELECT
      '스토렌_최종반환'                          AS "배송종류"
    , -1                                        AS "발송인"
    , ER.USER_CODE                              AS "수취인"
    , S.STOREN_ID                               AS "스토렌ID"
    , NULL                                      AS "보관ID"
    , NULL                                      AS "렌탈매칭완료ID"
    , NULL                                      AS "렌탈시작일"
    , NULL                                      AS "렌탈종료일"
    , NULL                                      AS "렌탈ID"
    , STLR.STOREN_LAST_RETURN_ID                AS "배송ID"               --최종반환 배송ID
    , EN.EQUIP_NAME                             AS "장비명"
    , NULL                                      AS "운송사이름"
    , NULL                                      AS "운송장번호"
    , STLR.DELIVERY_START_DATE                  AS "배송시작일"
    , STLR.DELIVERY_END_DATE                    AS "배송종료일"
    , IRA.COMPLETED_DATE                        AS "검수결과처리일"        --마지막 검수일
    , IRAT.INSPEC_RESULT_ACTION_TYPE_NAME       AS "검수결과처리유형"      --마지막 검수결과
FROM STOREN_LAST_RETURN STLR
JOIN STOREN S
     ON STLR.STOREN_ID = S.STOREN_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON S.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN INSPEC_RESULT_ACTION IRA
     ON STLR.INSPEC_RESULT_ACTION_ID = IRA.INSPEC_RESULT_ACTION_ID
JOIN INSPEC_RESULT_ACTION_TYPE IRAT
     ON IRA.INSPEC_RESULT_ACTION_TYPE_ID = IRAT.INSPEC_RESULT_ACTION_TYPE_ID

UNION ALL
-- 7. 보관_최종반환
SELECT
      '보관_최종반환'                          AS "배송종류"
    , -1                                        AS "발송인"
    , ER.USER_CODE                              AS "수취인"
    , NULL                                      AS "스토렌ID"
    , S.STORAGE_ID                              AS "보관ID"
    , NULL                                      AS "렌탈매칭완료ID"
    , NULL                                      AS "렌탈시작일"
    , NULL                                      AS "렌탈종료일"
    , NULL                                      AS "렌탈ID"
    , STLR.STORAGE_LAST_RETURN_ID               AS "배송ID"               --최종반환 배송ID
    , EN.EQUIP_NAME                             AS "장비명"
    , NULL                                      AS "운송사이름"
    , NULL                                      AS "운송장번호"
    , STLR.DELIVERY_START_DATE                  AS "배송시작일"
    , STLR.DELIVERY_END_DATE                    AS "배송종료일"
    , IRA.COMPLETED_DATE                        AS "검수결과처리일"        --마지막 검수일
    , IRAT.INSPEC_RESULT_ACTION_TYPE_NAME       AS "검수결과처리유형"      --마지막 검수결과
FROM STORAGE_LAST_RETURN STLR
JOIN STORAGE S
     ON STLR.STORAGE_ID = S.STORAGE_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON S.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN INSPEC_RESULT_ACTION IRA
     ON STLR.INSPEC_RESULT_ACTION_ID = IRA.INSPEC_RESULT_ACTION_ID
JOIN INSPEC_RESULT_ACTION_TYPE IRAT
     ON IRA.INSPEC_RESULT_ACTION_TYPE_ID = IRAT.INSPEC_RESULT_ACTION_TYPE_ID

UNION ALL
-- 8. 렌탈_사용자배송_반납
SELECT
      '렌탈_반납'                                AS "배송종류"
    , RMR.RENTAL_MATCHING_REQUESTER_ID          AS "발송인"
    , ER.USER_CODE                              AS "수취인"
    , P.STOREN_ID                               AS "스토렌ID"
    , P.STORAGE_ID                              AS "보관ID"
    , P.RENTAL_MATCHING_DONE_ID                 AS "렌탈매칭완료ID"
    , RMR.RENTAL_START_DATE                     AS "렌탈시작일"
    , RMR.RENTAL_END_DATE                       AS "렌탈종료일"
    , R.RENTAL_ID                               AS "렌탈ID"
    , UDR.USERS_DELIVERY_RETURN_ID              AS "배송ID"
    , EN.EQUIP_NAME                             AS "장비명"
    , UDR.CARRIER_NAME                          AS "운송사이름"
    , UDR.WAYBILL_NUMBER                        AS "운송장번호"
    , UDR.WAYBILL_ENTRY_DATE                    AS "배송시작일"
    , UDR.DELIVERY_END_DATE                     AS "배송종료일"
    , NULL                                      AS "검수결과처리일"
    , NULL                                      AS "검수결과처리유형"
FROM USERS_DELIVERY UD
JOIN PAY P
     ON UD.PAY_ID = P.PAY_ID
JOIN RENTAL_MATCHING_DONE RMD
     ON P.RENTAL_MATCHING_DONE_ID = RMD.RENTAL_MATCHING_DONE_ID
JOIN RENTAL_MATCHING_REQ RMR
     ON RMD.RENTAL_MATCHING_REQ_ID = RMR.RENTAL_MATCHING_REQ_ID
JOIN RENTAL R
     ON RMR.RENTAL_ID = R.RENTAL_ID
JOIN EQUIPMENT_REGISTRATION ER 
     ON R.EQUIP_CODE = ER.EQUIP_CODE
JOIN EQUIP_NAME EN
     ON ER.EQUIP_NAME_ID = EN.EQUIP_NAME_ID
JOIN USERS_DELIVERY_RETURN UDR
     ON UD.USERS_DELIVERY_ID = UDR.USERS_DELIVERY_ID
WHERE P.RENTAL_MATCHING_DONE_ID IS NOT NULL
/

