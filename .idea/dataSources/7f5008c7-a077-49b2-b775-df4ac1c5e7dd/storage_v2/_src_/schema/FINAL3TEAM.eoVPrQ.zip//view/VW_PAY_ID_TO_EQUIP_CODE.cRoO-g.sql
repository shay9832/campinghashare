create view VW_PAY_ID_TO_EQUIP_CODE as
SELECT 
     p.PAY_ID,
     -- 결제종류 컬럼
     CASE
          -- RENTAL_MATCHING_DONE_ID가 NULL이 아니면 '렌탈_렌탈비결제'
          WHEN p.RENTAL_MATCHING_DONE_ID IS NOT NULL
          THEN '렌탈_렌탈비결제'
          -- STORAGE_ID가 NULL이 아니면 '보관관_보관비결제'
          WHEN p.STORAGE_ID IS NOT NULL
          THEN '보관_보관비결제'
          -- STOREN_ID가 NULL이 아니면 '스토렌_보관비결제'
          WHEN p.STOREN_ID IS NOT NULL
          THEN '스토렌_보관비결제'
          -- STOREN_MATCHING_DONE_ID가 NULL이 아니면 '스토렌_렌탈비결제'
          WHEN p.STOREN_MATCHING_DONE_ID IS NOT NULL
          THEN '스토렌_렌탈비결제'
          -- 위의 모든 조건이 만족되지 않으면 NULL 반환
          ELSE NULL
     END AS 결제종류,
     
     -- 장비코드 컬럼럼
     CASE
          -- RENTAL_MATCHING_DONE_ID가 NULL이 아니면 RENTAL 테이블에서 EQUIP_CODE를 찾는다
          WHEN p.RENTAL_MATCHING_DONE_ID IS NOT NULL THEN 
          (  
               SELECT r.EQUIP_CODE
               FROM RENTAL_MATCHING_REQ rmq
               JOIN RENTAL r ON rmq.RENTAL_ID = r.RENTAL_ID
               WHERE rmq.RENTAL_MATCHING_REQ_ID = p.RENTAL_MATCHING_DONE_ID
          )
          -- STORAGE_ID가 NULL이 아니면 STORAGE 테이블에서 EQUIP_CODE를 찾는다
          WHEN p.STORAGE_ID IS NOT NULL THEN
          (  
               SELECT s.EQUIP_CODE
               FROM STORAGE s
               WHERE s.STORAGE_ID = p.STORAGE_ID
          )
          -- STOREN_ID가 NULL이 아니면 STOREN 테이블에서 EQUIP_CODE를 찾는다
          WHEN p.STOREN_ID IS NOT NULL THEN
          (  
               SELECT st.EQUIP_CODE
               FROM STOREN st
               WHERE st.STOREN_ID = p.STOREN_ID
          )
          -- STOREN_MATCHING_DONE_ID가 NULL이 아니면 INSPEC_RESULT_ACTION을 거쳐 EQUIP_CODE를 찾는다
          WHEN p.STOREN_MATCHING_DONE_ID IS NOT NULL THEN
          (  
               SELECT st.EQUIP_CODE
               FROM STOREN_MATCHING_REQ smr
               JOIN INSPEC_RESULT_ACTION ira ON smr.STOREN_IRA_ID = ira.INSPEC_RESULT_ACTION_ID
               JOIN INSPEC_RESULT ir ON ira.INSPEC_RESULT_ID = ir.INSPEC_RESULT_ID
               LEFT JOIN PLATFORM_DELIVERY pd ON ir.PLATFORM_DELIVERY_ID = pd.PLATFORM_DELIVERY_ID
               LEFT JOIN PLATFORM_DELIVERY_RETURN pdr ON ir.PLATFORM_DELIVERY_RETURN_ID = pdr.PLATFORM_DELIVERY_RETURN_ID
               LEFT JOIN PAY p2 ON pd.PAY_ID = p2.PAY_ID OR pdr.PLATFORM_DELIVERY_ID = p2.PAY_ID
               LEFT JOIN STOREN st ON p2.STOREN_ID = st.STOREN_ID
               WHERE smr.STOREN_MATCHING_REQ_ID = p.STOREN_MATCHING_DONE_ID
          )
          -- 위의 모든 조건이 만족되지 않으면 NULL 반환
          ELSE NULL
     END AS 장비코드
FROM 
     PAY p
/

